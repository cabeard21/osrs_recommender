export type ScreenType =
  | 'single-pre'
  | 'single-post'
  | 'single-inspector'
  | 'multi-side'
  | 'multi-interactive';

export type TransitionType = 'push' | 'push_back' | 'slide_up' | 'none';

export interface WeaponCandidate {
  id: string;
  name: string;
  rank: string;
  cost: string;
  costNumber: number;
  type: string;
  dps: number;
  dpsDelta: string;
  dpsDeltaPositive: boolean;
  maxHit: number;
  accuracy: string;
  speed: string;
  req: string;
  isBankOwned?: boolean;
  statusText?: string;
  statusBadge?: string;
  statusType?: 'optimal' | 'owned' | 'viable' | 'budget-exceeded' | 'mechanic-violated';
}
