import React, { useState } from 'react';

interface ChatGptModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialQuery?: string;
}

export const ChatGptModal: React.FC<ChatGptModalProps> = ({ isOpen, onClose, initialQuery }) => {
  const [query, setQuery] = useState(
    initialQuery || 'Ask ChatGPT what to prioritize before running optimization'
  );
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'assistant'; text: string }>>([
    {
      sender: 'assistant',
      text: 'Greetings Iron_Vann. I have ingested your bank inventory cache (8 items) and current combat profile (70 Atk, 70 Str, 70 Def). For Vorkath, your #1 capital efficiency bottleneck is upgrading from Dragon Scimitar to Abyssal Whip (62.7% of all potential damage gains for only 1.65M GP). Would you like me to evaluate liquidating items for Osmumten\'s Fang or configuring a 4-swap hybrid matrix?',
    },
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isThinking, setIsThinking] = useState(false);

  if (!isOpen) return null;

  const handleSend = (textToSend?: string) => {
    const text = textToSend || inputVal;
    if (!text.trim()) return;

    const newMsgs = [...messages, { sender: 'user' as const, text }];
    setMessages(newMsgs);
    setInputVal('');
    setIsThinking(true);

    setTimeout(() => {
      let reply = '';
      if (text.toLowerCase().includes('fang')) {
        reply =
          'Regarding Osmumten\'s Fang (14.2M GP): While it reaches 7.91 eDPS (+2.25 delta), liquidating 9.2M of core bank reserves at your stage provides negative net ROI compared to investing 1.65M in Abyssal Whip + 980K Obsidian Platelegs. Stick to the Whip baseline and save cash for Rigour.';
      } else if (text.toLowerCase().includes('swap') || text.toLowerCase().includes('range')) {
        reply =
          'For the 4-swap hybrid matrix: Switching to Toxic Blowpipe, Ava\'s, Anguish, and dropping the offhand provides 89.4% of maximum theoretical hybrid DPS while keeping 24/28 inventory slots free for brews and sharks during spawn walks.';
      } else {
        reply =
          'Analysis confirmed: Your current setup prioritizes maximum tick efficiency without degrading charges. Execute optimization to generate your GE Quick-Buy command.';
      }
      setMessages([...newMsgs, { sender: 'assistant' as const, text: reply }]);
      setIsThinking(false);
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-surface-container-low border border-surface-container-high rounded-xl w-full max-w-2xl shadow-2xl flex flex-col overflow-hidden max-h-[85vh]">
        {/* Header */}
        <div className="p-space-md bg-surface-container border-b border-surface-container-high flex items-center justify-between">
          <div className="flex items-center gap-space-sm text-primary">
            <span className="material-symbols-outlined text-[22px]">smart_toy</span>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                  ChatGPT MCP Intelligence Bridge
                </span>
                <span className="px-1.5 py-0.5 rounded bg-primary/20 text-primary text-[10px] font-data-sm font-semibold">
                  GPT-4o
                </span>
              </div>
              <span className="font-data-sm text-data-sm text-on-surface-variant">
                Direct RuneLite context feed: Iron_Vann bank cache synced
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-surface-container-high hover:bg-surface-container-highest text-on-surface-variant hover:text-on-surface flex items-center justify-center transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Chat message history */}
        <div className="flex-1 overflow-y-auto p-space-md space-y-space-md bg-surface-container-lowest/50">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.sender === 'assistant' && (
                <div className="w-8 h-8 rounded bg-primary/20 text-primary flex items-center justify-center shrink-0 mt-1">
                  <span className="material-symbols-outlined text-[18px]">smart_toy</span>
                </div>
              )}
              <div
                className={`max-w-[80%] rounded-lg p-space-md font-body-md text-body-md leading-relaxed ${
                  m.sender === 'user'
                    ? 'bg-primary text-on-primary font-medium'
                    : 'bg-surface-container text-on-surface border border-surface-container-high/60'
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
          {isThinking && (
            <div className="flex gap-3 items-center text-on-surface-variant font-data-sm text-data-sm">
              <span className="w-2 h-2 rounded-full bg-primary animate-ping"></span>
              <span>Evaluating bank permutations and GP/hr differential...</span>
            </div>
          )}
        </div>

        {/* Quick query presets */}
        <div className="px-space-md py-space-xs bg-surface-container border-t border-surface-container-high/40 flex items-center gap-2 overflow-x-auto text-xs">
          <button
            onClick={() => handleSend("Examine whether liquidating bank items for Fang is +GP/hr optimal.")}
            className="px-2.5 py-1 rounded bg-surface-container-high hover:bg-surface-container-highest text-primary transition-colors text-nowrap cursor-pointer"
          >
            "Whip vs Fang ROI"
          </button>
          <button
            onClick={() => handleSend("What is the optimal 4-swap configuration for Vorkath?")}
            className="px-2.5 py-1 rounded bg-surface-container-high hover:bg-surface-container-highest text-secondary transition-colors text-nowrap cursor-pointer"
          >
            "4-Swap Breakdown"
          </button>
          <button
            onClick={() => handleSend("Can I skip Obsidian Platelegs if budget is tight?")}
            className="px-2.5 py-1 rounded bg-surface-container-high hover:bg-surface-container-highest text-on-surface transition-colors text-nowrap cursor-pointer"
          >
            "Obsidian Legs Priority"
          </button>
        </div>

        {/* Input box */}
        <div className="p-space-md bg-surface-container-low border-t border-surface-container-high flex gap-2">
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask anything about gear, DPS thresholds, or budget tradeoffs..."
            className="flex-1 bg-surface-container-lowest border border-surface-container-high rounded-lg px-space-md py-2 font-body-md text-body-md text-on-surface focus:outline-none focus:border-primary"
          />
          <button
            onClick={() => handleSend()}
            className="px-space-lg py-2 rounded-lg bg-primary hover:bg-primary-container text-on-primary font-title-md font-bold transition-colors flex items-center gap-1 cursor-pointer"
          >
            <span>Send</span>
            <span className="material-symbols-outlined text-[16px]">send</span>
          </button>
        </div>
      </div>
    </div>
  );
};
