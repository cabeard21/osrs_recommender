import React from 'react';
import { ScreenType, TransitionType } from '../types';

interface HeaderProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentScreen, onNavigate, onOpenAdvisor }) => {
  const isSingleStyle =
    currentScreen === 'single-pre' ||
    currentScreen === 'single-post' ||
    currentScreen === 'single-inspector';
  const isMultiStyle = currentScreen === 'multi-side' || currentScreen === 'multi-interactive';

  const handleLoadoutOptimizerClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // Spec: Element (xpath: //header//a[@data-path='loadout-optimizer']) → Single-Style Optimizer — Pre-Optimization (none transition)
    onNavigate('single-pre', 'none');
  };

  const handleMultiStylePlannerClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // Spec: Element (xpath: //header//a[@data-path='multi-style-planner']) → Multi-Style Optimizer — Side-by-Side Comparison (none transition)
    onNavigate('multi-side', 'none');
  };

  return (
    <header className="fixed top-0 left-64 right-0 h-16 bg-surface-container-low/95 backdrop-blur-md z-40 px-space-lg flex items-center justify-between shadow-[0_1px_8px_rgba(0,0,0,0.3)] border-b border-surface-container-high/40 select-none">
      {/* Left: Branding & Target Info */}
      <div className="flex items-center gap-space-lg">
        <div className="flex items-center gap-space-sm">
          <span className="material-symbols-outlined text-primary text-[22px]">military_tech</span>
          <div className="flex flex-col">
            <span className="font-headline-sm text-headline-sm text-on-surface tracking-tight font-bold">
              RUNIC LEDGER <span className="text-primary font-data-sm text-data-sm">// GEAR OPTIMIZER</span>
            </span>
            <div className="flex items-center gap-space-xs">
              <span className="w-1.5 h-1.5 rounded-full bg-tertiary"></span>
              <span className="font-data-sm text-data-sm text-on-surface-variant">
                ONLINE (RuneLite Sync: 0.6s ago)
              </span>
            </div>
          </div>
        </div>

        <div className="hidden xl:flex items-center gap-space-sm bg-surface-container px-space-md py-space-xs rounded border border-surface-container-high/40">
          <span className="material-symbols-outlined text-secondary text-[16px]">radar</span>
          <span className="font-label-caps text-label-caps text-on-surface uppercase">Target:</span>
          <span className="font-data-sm text-data-sm text-primary font-semibold">Vorkath</span>
          <span className="font-data-sm text-data-sm text-on-surface-variant">[Lvl 732 · Slash Def: +26]</span>
        </div>
      </div>

      {/* Right: Mode Switcher & Account */}
      <div className="flex items-center gap-space-md">
        <div className="flex items-center bg-surface-container-lowest p-space-xs rounded border border-surface-container-high/50">
          <nav
            className="flex items-center gap-space-xs"
            data-active-classes="bg-surface-container text-primary font-bold shadow-sm"
          >
            <a
              aria-current={isSingleStyle ? 'page' : undefined}
              className={`px-space-md py-space-xs rounded uppercase transition-colors text-label-caps font-label-caps ${
                isSingleStyle
                  ? 'bg-surface-container text-primary font-bold shadow-sm border border-primary/20'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              data-path="loadout-optimizer"
              href="#"
              onClick={handleLoadoutOptimizerClick}
            >
              Single-Style
            </a>
            <a
              aria-current={isMultiStyle ? 'page' : undefined}
              className={`px-space-md py-space-xs rounded uppercase transition-colors text-label-caps font-label-caps ${
                isMultiStyle
                  ? 'bg-surface-container text-primary font-bold shadow-sm border border-primary/20'
                  : 'text-on-surface-variant hover:text-on-surface'
              }`}
              data-path="multi-style-planner"
              href="#"
              onClick={handleMultiStylePlannerClick}
            >
              Multi-Style (2-4)
            </a>
          </nav>
        </div>

        <div className="hidden lg:flex items-center gap-space-sm bg-surface-container px-space-md py-space-xs rounded border border-surface-container-high/40">
          <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">badge</span>
          <div className="flex flex-col">
            <span className="font-label-caps text-label-caps text-on-surface font-bold">Iron_Vann</span>
            <span className="font-data-sm text-data-sm text-on-surface-variant">70/70/70/75/70 · 8 synced</span>
          </div>
        </div>

        <button
          className="hidden sm:flex items-center gap-space-xs px-space-md py-space-xs rounded bg-surface-container-high hover:bg-surface-container-highest text-primary font-title-md text-title-md transition-colors border border-primary/20 cursor-pointer"
          data-path="ai-advisor"
          onClick={onOpenAdvisor}
          type="button"
        >
          <span className="material-symbols-outlined text-[16px]">smart_toy</span>
          <span>ChatGPT (MCP)</span>
        </button>

        <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 text-on-primary shadow-sm">
          <span className="material-symbols-outlined text-[18px]">person</span>
        </div>
      </div>
    </header>
  );
};
