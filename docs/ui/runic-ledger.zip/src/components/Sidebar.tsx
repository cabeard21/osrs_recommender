import React from 'react';
import { ScreenType, TransitionType } from '../types';

interface SidebarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentScreen, onNavigate }) => {
  const isSingleStyle =
    currentScreen === 'single-pre' ||
    currentScreen === 'single-post' ||
    currentScreen === 'single-inspector';
  const isMultiStyle = currentScreen === 'multi-side' || currentScreen === 'multi-interactive';

  const handleLoadoutOptimizerClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (currentScreen === 'single-inspector') {
      // Spec: Single-Style Optimizer — Item Inspector Open:
      // Element (xpath: //aside//a[@data-path='loadout-optimizer']) → Single-Style Optimizer — Post-Optimization (none transition)
      onNavigate('single-post', 'none');
    } else {
      // Spec: On other screens, goes to Single-Style Optimizer — Pre-Optimization (none transition)
      onNavigate('single-pre', 'none');
    }
  };

  const handleMultiStylePlannerClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // Spec: Element (xpath: //aside//a[@data-path='multi-style-planner']) → Multi-Style Optimizer — Side-by-Side Comparison (none transition)
    onNavigate('multi-side', 'none');
  };

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-surface-container-lowest z-50 flex flex-col justify-between shadow-[0_1px_8px_rgba(0,0,0,0.4)] select-none">
      <div className="flex flex-col">
        {/* App Title Header */}
        <div className="h-16 px-space-lg flex items-center gap-space-sm bg-surface-container-low border-b border-surface-container-high/40">
          <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-primary shadow-inner">
            <span className="material-symbols-outlined text-[20px]">token</span>
          </div>
          <div className="flex flex-col">
            <span className="font-label-caps text-label-caps text-on-surface tracking-wider uppercase font-bold">
              Runic Vault
            </span>
            <span className="font-data-sm text-data-sm text-primary">ENGINE // v4.20</span>
          </div>
        </div>

        {/* Category Header */}
        <div className="px-space-md py-space-sm">
          <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-widest px-space-sm opacity-60">
            Operations
          </span>
        </div>

        {/* Navigation Menu */}
        <nav
          className="flex flex-col gap-space-xs px-space-sm"
          data-active-classes="bg-surface-container-high text-primary font-bold shadow-inner"
        >
          <a
            aria-current={isSingleStyle ? 'page' : undefined}
            className={`flex items-center gap-space-md px-space-md py-space-sm rounded transition-colors ${
              isSingleStyle
                ? 'bg-surface-container-high text-primary font-bold shadow-inner'
                : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
            }`}
            data-path="loadout-optimizer"
            href="#"
            onClick={handleLoadoutOptimizerClick}
          >
            <span className="material-symbols-outlined text-[18px]">shield</span>
            <span className="font-title-md text-title-md">Loadout Optimizer</span>
          </a>

          <a
            aria-current={isMultiStyle ? 'page' : undefined}
            className={`flex items-center gap-space-md px-space-md py-space-sm rounded transition-colors ${
              isMultiStyle
                ? 'bg-surface-container-high text-primary font-bold shadow-inner'
                : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
            }`}
            data-path="multi-style-planner"
            href="#"
            onClick={handleMultiStylePlannerClick}
          >
            <span className="material-symbols-outlined text-[18px]">swap_horiz</span>
            <span className="font-title-md text-title-md">Multi-Style Planner</span>
          </a>

          <a
            className="flex items-center gap-space-md px-space-md py-space-sm rounded text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-colors opacity-75 hover:opacity-100"
            data-path="boss-encounters"
            href="#"
            onClick={(e) => e.preventDefault()}
          >
            <span className="material-symbols-outlined text-[18px]">swords</span>
            <span className="font-title-md text-title-md">Boss Encounters</span>
          </a>

          <a
            className="flex items-center gap-space-md px-space-md py-space-sm rounded text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-colors opacity-75 hover:opacity-100"
            data-path="bank-and-vault-cache"
            href="#"
            onClick={(e) => e.preventDefault()}
          >
            <span className="material-symbols-outlined text-[18px]">inventory_2</span>
            <span className="font-title-md text-title-md">Bank &amp; Vault Cache</span>
          </a>

          <a
            className="flex items-center gap-space-md px-space-md py-space-sm rounded text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-colors opacity-75 hover:opacity-100"
            data-path="upgrade-ledger"
            href="#"
            onClick={(e) => e.preventDefault()}
          >
            <span className="material-symbols-outlined text-[18px]">trending_up</span>
            <span className="font-title-md text-title-md">Upgrade Ledger</span>
          </a>
        </nav>
      </div>

      {/* Footer Settings & Live Status */}
      <div className="flex flex-col gap-space-xs p-space-sm bg-surface-container-lowest border-t border-surface-container-high/40">
        <nav className="flex flex-col">
          <a
            className="flex items-center gap-space-md px-space-md py-space-sm rounded text-on-surface-variant hover:bg-surface-container hover:text-on-surface transition-colors"
            data-path="settings"
            href="#"
            onClick={(e) => e.preventDefault()}
          >
            <span className="material-symbols-outlined text-[18px]">tune</span>
            <span className="font-title-md text-title-md">Settings</span>
          </a>
        </nav>

        <div className="mt-space-xs p-space-sm rounded bg-surface-container-low flex items-center justify-between border border-surface-container-high/30">
          <div className="flex items-center gap-space-sm">
            <div className="w-2 h-2 rounded-full bg-tertiary animate-pulse"></div>
            <span className="font-data-sm text-data-sm text-on-surface-variant">RuneLite Bridge</span>
          </div>
          <span className="font-data-sm text-data-sm text-tertiary">0.6s</span>
        </div>
      </div>
    </aside>
  );
};
