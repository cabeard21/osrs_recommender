import React, { useState, useEffect } from 'react';
import { ScreenType, TransitionType, WeaponCandidate } from '../types';

interface SingleItemInspectorProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: (prompt?: string) => void;
}

const INITIAL_CANDIDATES: WeaponCandidate[] = [
  {
    id: 'whip',
    name: 'Abyssal Whip',
    rank: '01',
    cost: '~1,650,000 GP',
    costNumber: 1650000,
    type: '4t Slash · 1-Handed',
    dps: 6.84,
    dpsDelta: '+1.18 Delta',
    dpsDeltaPositive: true,
    maxHit: 42,
    accuracy: '64.2%',
    speed: '4 Ticks (2.4s)',
    req: 'Req Met (70 Atk)',
    statusBadge: 'Active Pick',
    statusType: 'optimal',
  },
  {
    id: 'scimitar',
    name: 'Dragon Scimitar',
    rank: '02',
    cost: '0 GP · Baseline Item',
    costNumber: 0,
    type: '4t Slash · 1-Handed',
    dps: 5.66,
    dpsDelta: '0.00 Base',
    dpsDeltaPositive: false,
    maxHit: 36,
    accuracy: '55.8%',
    speed: '4 Ticks (2.4s)',
    req: 'Req Met (60 Atk)',
    isBankOwned: true,
    statusBadge: 'Bank Owned',
    statusType: 'owned',
  },
  {
    id: 'dagger',
    name: 'Abyssal Dagger (p++)',
    rank: '03',
    cost: '2.80M GP',
    costNumber: 2800000,
    type: '4t Stab Focus · Spec Bonus',
    dps: 6.42,
    dpsDelta: '+0.76 Delta',
    dpsDeltaPositive: true,
    maxHit: 40,
    accuracy: '60.4%',
    speed: '4 Ticks (2.4s)',
    req: 'Req Met (70 Atk)',
    statusType: 'viable',
  },
  {
    id: 'fang',
    name: "Osmumten's Fang",
    rank: '04',
    cost: '14.2M GP',
    costNumber: 14200000,
    type: '5t High Def Double-Roll',
    dps: 7.91,
    dpsDelta: '+2.25 Delta',
    dpsDeltaPositive: true,
    maxHit: 48,
    accuracy: '76.8%',
    speed: '5 Ticks (3.0s)',
    req: 'Req Met (82 Atk)',
    statusBadge: 'Exceeds Budget (+9.2M)',
    statusType: 'budget-exceeded',
  },
  {
    id: 'sara_sword',
    name: 'Saradomin Sword',
    rank: '05',
    cost: '750k GP',
    costNumber: 750000,
    type: '2-Handed weapon bans shield',
    dps: 6.15,
    dpsDelta: 'Unviable',
    dpsDeltaPositive: false,
    maxHit: 43,
    accuracy: '62.0%',
    speed: '4 Ticks (2.4s)',
    req: 'Req Met (70 Atk)',
    statusBadge: 'Violates Shield Mech',
    statusType: 'mechanic-violated',
  },
  {
    id: 'rapier',
    name: 'Ghrazi Rapier',
    rank: '06',
    cost: '52.0M GP',
    costNumber: 52000000,
    type: '4t Stab Biased',
    dps: 7.15,
    dpsDelta: '+1.49 Delta',
    dpsDeltaPositive: true,
    maxHit: 44,
    accuracy: '67.2%',
    speed: '4 Ticks (2.4s)',
    req: 'Req Met (75 Atk)',
    statusBadge: 'Exceeds Budget',
    statusType: 'budget-exceeded',
  },
];

export const SingleItemInspector: React.FC<SingleItemInspectorProps> = ({
  onNavigate,
  onOpenAdvisor,
}) => {
  const [selectedWeaponId, setSelectedWeaponId] = useState<string>('whip');
  const [isLocked, setIsLocked] = useState(false);
  const [isExcluded, setIsExcluded] = useState(false);
  const [simActive, setSimActive] = useState(false);

  const activeWeapon =
    INITIAL_CANDIDATES.find((c) => c.id === selectedWeaponId) || INITIAL_CANDIDATES[0];

  // Esc key closes inspector
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onNavigate('single-post', 'push_back');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onNavigate]);

  const handleCloseInspector = () => {
    // Spec: Element (xpath: //button[contains(., 'Close Inspector')]) → Single-Style Optimizer — Post-Optimization (push_back transition)
    onNavigate('single-post', 'push_back');
  };

  const handleRerunOptimizer = () => {
    // Spec: Element (xpath: //button[contains(., 'Re-run Optimizer')]) → Single-Style Optimizer — Pre-Optimization (push_back transition)
    onNavigate('single-pre', 'push_back');
  };

  return (
    <div className="flex flex-col w-full text-on-surface select-none pb-space-lg">
      {/* Top Utility Context Bar */}
      <section className="w-full bg-surface-container-low px-space-lg py-space-sm flex items-center justify-between shadow-sm border-b border-surface-container-high/40">
        <div className="flex items-center gap-space-md">
          <div className="flex items-center gap-space-xs bg-surface-container px-space-sm py-0.5 rounded border border-surface-container-high/30">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>
            <span className="font-label-caps text-label-caps text-primary tracking-wider uppercase">
              Live Inspector Session
            </span>
          </div>
          <div className="flex items-center gap-space-xs text-on-surface-variant font-data-sm text-data-sm">
            <span className="text-on-surface">MODE: SINGLE-STYLE</span>
            <span>//</span>
            <span className="text-primary font-semibold">ITEM INSPECTION ACTIVE</span>
            <span className="bg-surface-container-high px-space-xs py-0.2 rounded text-secondary border border-secondary/20">
              [Slot 04: Mainhand Weapon]
            </span>
          </div>
        </div>

        <div className="flex items-center gap-space-md">
          <div className="hidden md:flex items-center gap-space-xs bg-surface-container-lowest px-space-sm py-1 rounded border border-surface-container-high/40">
            <span className="material-symbols-outlined text-[15px] text-tertiary">check_circle</span>
            <span className="font-data-sm text-data-sm text-on-surface-variant">
              Active Seed: <span className="text-on-surface font-semibold">#VK-732-S04</span>
            </span>
          </div>

          {/* Re-run Optimizer button (push_back transition) */}
          <button
            onClick={handleRerunOptimizer}
            className="flex items-center gap-space-xs px-space-md py-1 rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-title-md text-title-md transition-colors cursor-pointer border border-surface-container-high/40"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px] text-primary">sync</span>
            <span>Re-run Optimizer</span>
          </button>

          {/* Close Inspector button (push_back transition) */}
          <button
            onClick={handleCloseInspector}
            className="flex items-center gap-space-xs px-space-md py-1 rounded bg-surface-container-high hover:bg-surface-container-highest text-error font-title-md text-title-md transition-colors cursor-pointer border border-error/30"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">close</span>
            <span>
              Close Inspector <span className="text-on-surface-variant text-[11px] font-data-sm">[Esc]</span>
            </span>
          </button>
        </div>
      </section>

      {/* Main Three-Column Layout */}
      <div className="w-full grid grid-cols-12 gap-space-md p-space-md max-w-[1920px] mx-auto">
        {/* Column 1: Configuration & Encounter Context (3 cols) */}
        <div className="col-span-12 lg:col-span-3 flex flex-col gap-space-md">
          {/* Encounter Target Card */}
          <div className="bg-surface-container rounded-lg p-space-md shadow-md flex flex-col gap-space-sm relative overflow-hidden border border-surface-container-high/40">
            <div className="absolute -right-4 -top-4 w-28 h-28 bg-primary/5 rounded-full blur-2xl pointer-events-none"></div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">swords</span>
                <span className="font-label-caps text-label-caps text-primary tracking-wider uppercase">
                  Target Profile
                </span>
              </div>
              <span className="font-data-sm text-data-sm bg-surface-container-lowest px-space-xs py-0.5 rounded text-secondary border border-surface-container-high/30">
                ID #8061
              </span>
            </div>
            <div className="flex items-center gap-space-md bg-surface-container-lowest p-space-sm rounded border border-surface-container-high/40">
              <div className="w-12 h-12 rounded bg-surface-container-high flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-secondary text-[28px]">token</span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-space-xs">
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold truncate">
                    Vorkath
                  </span>
                  <span className="font-data-sm text-data-sm text-error bg-error-container/30 px-space-xs py-0.2 rounded font-semibold">
                    Lvl 732
                  </span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">
                  Undead · Dragonkin Prototype
                </span>
              </div>
            </div>
            {/* Target Attributes Grid */}
            <div className="grid grid-cols-2 gap-space-xs font-data-sm text-data-sm">
              <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/30">
                <span className="text-on-surface-variant text-[10px]">DEFENCE LVL</span>
                <span className="font-semibold text-on-surface">214 (Roll: 13,760)</span>
              </div>
              <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/30">
                <span className="text-on-surface-variant text-[10px]">SLASH DEF</span>
                <span className="font-semibold text-tertiary">+26 (Optimal)</span>
              </div>
              <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/30">
                <span className="text-on-surface-variant text-[10px]">STAB DEF</span>
                <span className="font-semibold text-on-surface-variant">+26</span>
              </div>
              <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/30">
                <span className="text-on-surface-variant text-[10px]">CRUSH DEF</span>
                <span className="font-semibold text-on-surface-variant">+108</span>
              </div>
            </div>
            {/* Target Mechanics Hazard */}
            <div className="bg-error-container/20 rounded p-space-xs flex items-center gap-space-xs border border-error/30">
              <span className="material-symbols-outlined text-error text-[16px]">local_fire_department</span>
              <span className="font-data-sm text-data-sm text-on-surface">
                Dragonfire Hazard: <span className="font-semibold text-error">Shield Required</span>
              </span>
            </div>
          </div>

          {/* Budget & Inventory Allocation */}
          <div className="bg-surface-container rounded-lg p-space-md shadow-md flex flex-col gap-space-sm border border-surface-container-high/40">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">
                  account_balance_wallet
                </span>
                <span className="font-label-caps text-label-caps text-primary tracking-wider uppercase">
                  Liquidity Allocation
                </span>
              </div>
              <span className="font-data-sm text-data-sm text-tertiary">SURPLUS: +2.185M</span>
            </div>
            <div className="bg-surface-container-lowest p-space-sm rounded flex flex-col gap-space-xs border border-surface-container-high/30">
              <div className="flex justify-between items-baseline">
                <span className="font-label-caps text-label-caps text-on-surface-variant">ALLOCATED / CAP</span>
                <span className="font-data-lg text-data-lg text-primary font-bold">
                  2,815,000 <span className="text-on-surface-variant text-[12px]">/ 5.0M GP</span>
                </span>
              </div>
              {/* Progress bar */}
              <div className="w-full h-2 rounded bg-surface-container-high overflow-hidden flex">
                <div className="h-full bg-primary" style={{ width: '56.3%' }}></div>
                <div className="h-full bg-surface-variant" style={{ width: '43.7%' }}></div>
              </div>
              <div className="flex justify-between items-center text-[10px] font-data-sm text-on-surface-variant pt-1">
                <span>Utilization: 56.3%</span>
                <span className="text-tertiary">Safe Margin (43.7% Free)</span>
              </div>
            </div>
            {/* Breakdown List */}
            <div className="flex flex-col gap-space-xs font-data-sm text-data-sm">
              <div className="flex justify-between items-center py-1 px-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <span className="text-on-surface-variant">Slot 04 (Mainhand):</span>
                <span className="text-primary font-semibold">1,650,000 GP (58.6%)</span>
              </div>
              <div className="flex justify-between items-center py-1 px-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <span className="text-on-surface-variant">Slot 08 (Boots):</span>
                <span className="text-on-surface">415,000 GP</span>
              </div>
              <div className="flex justify-between items-center py-1 px-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <span className="text-on-surface-variant">Slot 06 (Legs):</span>
                <span className="text-on-surface">750,000 GP</span>
              </div>
              <div className="flex justify-between items-center py-1 px-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <span className="text-on-surface-variant">Vaulted / Untradeable:</span>
                <span className="text-tertiary font-semibold">0 GP (7 Slots)</span>
              </div>
            </div>
          </div>

          {/* Constraint Ledger & Directives */}
          <div className="bg-surface-container rounded-lg p-space-md shadow-md flex flex-col gap-space-sm border border-surface-container-high/40">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">rule</span>
                <span className="font-label-caps text-label-caps text-primary tracking-wider uppercase">
                  Solver Directives
                </span>
              </div>
              <span className="font-data-sm text-data-sm text-secondary bg-surface-container-high px-space-xs py-0.2 rounded">
                1 Slot Fixed
              </span>
            </div>
            <div className="flex flex-col gap-space-xs">
              {/* Active Lock */}
              <div className="flex items-center justify-between p-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-secondary text-[16px]">lock</span>
                  <span className="font-body-sm text-body-sm text-on-surface">
                    Slot 05: Anti-Dragon Shield
                  </span>
                </div>
                <span className="font-data-sm text-data-sm text-secondary uppercase text-[10px] font-bold">
                  Hard Lock
                </span>
              </div>
              <div className="flex items-center justify-between p-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-tertiary text-[16px]">verified</span>
                  <span className="font-body-sm text-body-sm text-on-surface">Slayer Task Profile</span>
                </div>
                <span className="font-data-sm text-data-sm text-tertiary uppercase text-[10px] font-bold">
                  Blue Dragon
                </span>
              </div>
              <div className="flex items-center justify-between p-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-primary text-[16px]">filter_alt</span>
                  <span className="font-body-sm text-body-sm text-on-surface">Style Bias</span>
                </div>
                <span className="font-data-sm text-data-sm text-primary uppercase text-[10px] font-bold">
                  Pure Slash Melee
                </span>
              </div>
            </div>
          </div>

          {/* Quick Session Telemetry */}
          <div className="bg-surface-container-lowest rounded p-space-sm flex items-center justify-between font-data-sm text-data-sm border border-surface-container-high/30">
            <div className="flex items-center gap-space-xs text-on-surface-variant">
              <span className="material-symbols-outlined text-[14px]">memory</span>
              <span>Simulation Cycles: 184,290</span>
            </div>
            <span className="text-tertiary font-bold">0.042s</span>
          </div>
        </div>

        {/* Column 2: Equipment Paperdoll Grid with Active Slot Focus (4 cols) */}
        <div className="col-span-12 lg:col-span-4 flex flex-col gap-space-md">
          <div className="bg-surface-container rounded-lg p-space-md shadow-md flex flex-col gap-space-md h-full justify-between border border-surface-container-high/40">
            {/* Paperdoll Header */}
            <div className="flex items-center justify-between">
              <div className="flex flex-col">
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    accessibility_new
                  </span>
                  <span className="font-label-caps text-label-caps text-on-surface uppercase tracking-wider font-bold">
                    Equipment Matrix
                  </span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">
                  Click any slot to switch inspector context
                </span>
              </div>
              <span className="font-data-sm text-data-sm bg-primary/20 text-primary px-space-sm py-0.5 rounded font-bold uppercase border border-primary/20">
                Melee (Slash)
              </span>
            </div>

            {/* OSRS 11-Slot Paperdoll Grid */}
            <div className="relative py-space-sm flex flex-col items-center justify-center">
              {/* Row 1: Head */}
              <div className="flex justify-center mb-space-sm">
                <div className="w-16 h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-primary text-[28px]">smart_toy</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Slayer Helm (i)
                  </span>
                  <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-tertiary"></span>
                </div>
              </div>

              {/* Row 2: Cape, Neck, Ammo */}
              <div className="grid grid-cols-3 gap-space-md mb-space-sm w-full max-w-[280px]">
                {/* Cape */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-error text-[26px]">flag</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Fire Cape
                  </span>
                </div>
                {/* Neck */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-secondary text-[26px]">diamond</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Fury
                  </span>
                </div>
                {/* Ammo */}
                <div className="h-16 bg-surface-container-low rounded p-1 flex flex-col items-center justify-center relative opacity-40 border border-surface-container-high/20">
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">adjust</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant">Empty</span>
                </div>
              </div>

              {/* Row 3: Weapon (ACTIVE INSPECTED), Body, Shield */}
              <div className="grid grid-cols-3 gap-space-md mb-space-sm w-full max-w-[280px]">
                {/* Mainhand Weapon (SLOT 04 - HIGHLIGHTED) */}
                <div className="h-16 bg-surface-container-highest rounded p-1 flex flex-col items-center justify-center relative cursor-pointer ring-2 ring-primary shadow-[0_0_12px_rgba(240,191,92,0.35)] scale-105 z-10 transition-transform">
                  <span className="material-symbols-outlined text-primary text-[28px]">sports_martial_arts</span>
                  <span className="text-[9px] font-data-sm text-primary font-bold truncate max-w-full">
                    {activeWeapon.name}
                  </span>
                  {/* Inspected Badge */}
                  <span className="absolute -top-2 -left-2 bg-primary text-on-primary font-label-caps text-[8px] font-bold px-1 py-0.2 rounded shadow">
                    INSPECTED
                  </span>
                </div>
                {/* Body */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-primary text-[26px]">shield</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Torso
                  </span>
                </div>
                {/* Shield (LOCKED) */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-secondary text-[26px]">security</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Anti-Dragon
                  </span>
                  <span className="absolute top-1 right-1 material-symbols-outlined text-[13px] text-secondary">
                    lock
                  </span>
                </div>
              </div>

              {/* Row 4: Legs */}
              <div className="flex justify-center mb-space-sm">
                <div className="w-16 h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-on-surface text-[26px]">
                    airline_seat_legroom_extra
                  </span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Obsidian Legs
                  </span>
                </div>
              </div>

              {/* Row 5: Hands, Feet, Ring */}
              <div className="grid grid-cols-3 gap-space-md w-full max-w-[280px]">
                {/* Gloves */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-primary text-[24px]">front_hand</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Barrows
                  </span>
                </div>
                {/* Boots */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-error text-[24px]">snowshoeing</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    Dragon Boots
                  </span>
                </div>
                {/* Ring */}
                <div className="h-16 bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative cursor-pointer hover:bg-surface-container-highest transition-all group border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-secondary text-[24px]">adjust</span>
                  <span className="text-[9px] font-data-sm text-on-surface-variant group-hover:text-on-surface truncate max-w-full">
                    B-Ring (i)
                  </span>
                </div>
              </div>
            </div>

            {/* Aggregate Combat Performance Banner */}
            <div className="bg-surface-container-lowest rounded-lg p-space-md flex flex-col gap-space-xs border border-surface-container-high/30">
              <div className="flex items-center justify-between pb-1">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Full Setup Telemetry
                </span>
                <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-tertiary"></span>Optimal Threshold
                </span>
              </div>
              <div className="grid grid-cols-3 gap-space-xs text-center py-space-xs bg-surface-container-low rounded border border-surface-container-high/20">
                <div className="flex flex-col">
                  <span className="text-[10px] font-data-sm text-on-surface-variant">ESTIMATED DPS</span>
                  <span className="font-data-lg text-data-lg text-primary font-bold">
                    {activeWeapon.dps}
                  </span>
                  <span className="text-[10px] font-data-sm text-tertiary">
                    {activeWeapon.dpsDelta}
                  </span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-data-sm text-on-surface-variant">MAX HIT</span>
                  <span className="font-data-lg text-data-lg text-on-surface font-bold">
                    {activeWeapon.maxHit}
                  </span>
                  <span className="text-[10px] font-data-sm text-on-surface-variant">Super Combat</span>
                </div>
                <div className="flex flex-col">
                  <span className="text-[10px] font-data-sm text-on-surface-variant">ACCURACY</span>
                  <span className="font-data-lg text-data-lg text-secondary font-bold">
                    {activeWeapon.accuracy}
                  </span>
                  <span className="text-[10px] font-data-sm text-on-surface-variant">vs +26 Def</span>
                </div>
              </div>
              <div className="flex items-center justify-between font-data-sm text-data-sm text-on-surface-variant pt-1 px-space-xs">
                <span>
                  Avg Kill Time: <span className="text-on-surface font-semibold">1m 48s</span>
                </span>
                <span>
                  Food Required: <span className="text-on-surface font-semibold">2.4 / Kill</span>
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Column 3: Unified Item Inspector — Comprehensive Detail (5 cols) */}
        <div className="col-span-12 lg:col-span-5 flex flex-col gap-space-md">
          {/* Unified Header */}
          <div className="bg-surface-container rounded-lg p-space-md shadow-md flex flex-col gap-space-sm border border-surface-container-high/40">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[20px]">manage_search</span>
                <div className="flex flex-col">
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold leading-none">
                    Item Inspector
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">
                    Slot: <span className="text-primary font-semibold">Mainhand Weapon (Slot 04)</span>
                  </span>
                </div>
              </div>
              <span className="font-data-sm text-data-sm bg-surface-container-high text-on-surface-variant px-space-sm py-0.5 rounded border border-surface-container-high/40">
                6 Candidates Evaluated
              </span>
            </div>

            {/* Selected Item Main Profile Card */}
            <div className="bg-surface-container-lowest rounded-lg p-space-md flex flex-col gap-space-sm relative border border-surface-container-high/40">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-space-md">
                  <div className="w-14 h-14 rounded-lg bg-surface-container-high p-1 flex items-center justify-center relative ring-1 ring-primary/40 shrink-0">
                    <span className="material-symbols-outlined text-primary text-[32px]">
                      sports_martial_arts
                    </span>
                    <span className="absolute bottom-1 right-1 text-[9px] font-data-sm bg-surface-container-lowest px-1 rounded text-primary">
                      T70
                    </span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <div className="flex items-center gap-space-xs flex-wrap">
                      <h3 className="font-headline-lg text-headline-lg text-primary font-bold leading-tight">
                        {activeWeapon.name}
                      </h3>
                      <span className="bg-tertiary-container/30 text-tertiary px-space-xs py-0.2 rounded font-data-sm text-data-sm flex items-center gap-1 border border-tertiary/20">
                        <span className="material-symbols-outlined text-[13px]">check</span>
                        {activeWeapon.req}
                      </span>
                    </div>
                    <div className="flex items-center gap-space-sm font-data-sm text-data-sm text-on-surface-variant mt-0.5">
                      <span className="flex items-center gap-1 text-on-surface">
                        <span className="material-symbols-outlined text-[14px] text-primary">shopping_cart</span>
                        GE Price: {activeWeapon.cost}
                      </span>
                      <span>·</span>
                      <span className="text-tertiary">Live Probe Accurate</span>
                    </div>
                  </div>
                </div>

                {/* Role Badge */}
                <div className="flex flex-col items-end">
                  <span className="bg-primary text-on-primary font-label-caps text-label-caps px-space-sm py-0.5 rounded font-bold uppercase shadow-sm">
                    {activeWeapon.statusBadge || 'Candidate'}
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant text-[10px] mt-0.5">
                    Rank #{activeWeapon.rank}
                  </span>
                </div>
              </div>

              {/* Combat Specs */}
              <div className="grid grid-cols-3 gap-space-xs pt-space-xs font-data-sm text-data-sm">
                <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/20">
                  <span className="text-[10px] text-on-surface-variant">SLASH ATTACK</span>
                  <span className="font-data-md text-data-md font-bold text-on-surface">+82</span>
                </div>
                <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/20">
                  <span className="text-[10px] text-on-surface-variant">MELEE STRENGTH</span>
                  <span className="font-data-md text-data-md font-bold text-on-surface">+82</span>
                </div>
                <div className="bg-surface-container-low p-space-xs rounded flex flex-col border border-surface-container-high/20">
                  <span className="text-[10px] text-on-surface-variant">ATTACK SPEED</span>
                  <span className="font-data-md text-data-md font-bold text-secondary">
                    {activeWeapon.speed}
                  </span>
                </div>
              </div>

              {/* Compatibility and Mechanical Integrity */}
              <div className="bg-surface-container-low p-space-xs rounded flex items-center gap-space-xs font-data-sm text-data-sm text-tertiary border border-surface-container-high/20">
                <span className="material-symbols-outlined text-[16px]">shield</span>
                <span>
                  Allows 1-Handed Off-Hands:{' '}
                  <span className="font-semibold text-on-surface">Anti-Dragon Shield Compatible</span>
                </span>
              </div>

              {/* Calculated Impact on Encounter */}
              <div className="bg-surface-container-high/60 rounded p-space-sm flex items-center justify-between font-data-sm text-data-sm border border-surface-container-high/40">
                <div className="flex flex-col">
                  <span className="text-[11px] text-on-surface-variant">TOTAL DPS CONTRIBUTION</span>
                  <span className="font-data-lg text-data-lg text-primary font-bold">
                    {activeWeapon.dps} eDPS
                  </span>
                </div>
                <div className="flex flex-col items-end">
                  <span className="text-[11px] text-tertiary font-bold">
                    {activeWeapon.dpsDelta} vs Baseline Setup
                  </span>
                  <span className="text-[10px] text-on-surface-variant">
                    62.7% of total loadout offensive gain
                  </span>
                </div>
              </div>

              {/* Action Bar: Lock, Exclude, Sim */}
              <div className="grid grid-cols-3 gap-space-xs pt-space-xs">
                <button
                  type="button"
                  onClick={() => setIsLocked(!isLocked)}
                  className={`flex items-center justify-center gap-space-xs px-space-xs py-1.5 rounded font-title-md text-title-md transition-colors cursor-pointer border ${
                    isLocked
                      ? 'bg-secondary text-on-secondary border-secondary'
                      : 'bg-surface-container-high hover:bg-surface-container-highest text-on-surface border-surface-container-high/40'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px] text-secondary">lock</span>
                  <span className="text-[12px]">{isLocked ? 'Locked' : 'Lock in Setup'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsExcluded(!isExcluded)}
                  className={`flex items-center justify-center gap-space-xs px-space-xs py-1.5 rounded font-title-md text-title-md transition-colors cursor-pointer border ${
                    isExcluded
                      ? 'bg-error text-on-error border-error'
                      : 'bg-surface-container-high hover:bg-surface-container-highest text-error border-surface-container-high/40'
                  }`}
                >
                  <span className="material-symbols-outlined text-[15px]">block</span>
                  <span className="text-[12px]">{isExcluded ? 'Excluded' : 'Exclude Item'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSimActive(!simActive)}
                  className="flex items-center justify-center gap-space-xs px-space-xs py-1.5 rounded bg-primary hover:bg-primary-container text-on-primary font-title-md text-title-md transition-colors cursor-pointer shadow-sm"
                >
                  <span className="material-symbols-outlined text-[15px]">bolt</span>
                  <span className="text-[12px]">{simActive ? 'Sim Active' : 'Sim What-If'}</span>
                </button>
              </div>
            </div>

            {/* Equipment Alternatives Ranking */}
            <div className="flex flex-col gap-space-xs mt-space-xs">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-label-caps text-on-surface uppercase tracking-wider">
                  Slot Candidates Ranked vs Target
                </span>
                <span className="font-data-sm text-data-sm text-on-surface-variant">
                  Sorted by Realized DPS
                </span>
              </div>
              <div className="flex flex-col gap-space-xs max-h-[310px] overflow-y-auto pr-1">
                {INITIAL_CANDIDATES.map((cand) => {
                  const isCurrent = cand.id === selectedWeaponId;
                  const isViolation = cand.statusType === 'mechanic-violated';
                  const isOverBudget = cand.statusType === 'budget-exceeded';

                  return (
                    <div
                      key={cand.id}
                      className={`p-space-sm rounded flex items-center justify-between transition-colors border ${
                        isCurrent
                          ? 'bg-surface-container-lowest ring-1 ring-primary/60 border-primary/40'
                          : isViolation
                          ? 'bg-surface-container-low/50 opacity-60 border-surface-container-high/20'
                          : isOverBudget
                          ? 'bg-surface-container-low/70 opacity-80 border-surface-container-high/20'
                          : 'bg-surface-container-low hover:bg-surface-container-high border-surface-container-high/30'
                      }`}
                    >
                      <div className="flex items-center gap-space-sm min-w-0">
                        <span
                          className={`font-data-sm text-data-sm font-bold w-4 ${
                            isCurrent ? 'text-primary' : 'text-on-surface-variant'
                          }`}
                        >
                          {cand.rank}
                        </span>
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-space-xs flex-wrap">
                            <span
                              className={`font-title-md text-title-md truncate font-semibold ${
                                isViolation ? 'line-through text-on-surface-variant' : 'text-on-surface'
                              } ${isCurrent ? 'text-primary font-bold' : ''}`}
                            >
                              {cand.name}
                            </span>
                            {cand.statusBadge && (
                              <span
                                className={`text-[10px] font-data-sm px-1 rounded uppercase font-bold ${
                                  cand.statusType === 'optimal'
                                    ? 'bg-primary/20 text-primary'
                                    : cand.statusType === 'owned'
                                    ? 'bg-tertiary-container/20 text-tertiary'
                                    : cand.statusType === 'mechanic-violated'
                                    ? 'bg-error text-on-error'
                                    : 'bg-error-container/30 text-error'
                                }`}
                              >
                                {cand.statusBadge}
                              </span>
                            )}
                          </div>
                          <span className="font-data-sm text-data-sm text-on-surface-variant">
                            {cand.cost} · {cand.type}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-space-md shrink-0">
                        <div className="flex flex-col items-end">
                          <span
                            className={`font-data-md text-data-md font-bold ${
                              isCurrent
                                ? 'text-primary'
                                : isViolation
                                ? 'text-on-surface-variant'
                                : isOverBudget
                                ? 'text-tertiary'
                                : 'text-on-surface'
                            }`}
                          >
                            {cand.dps} DPS
                          </span>
                          <span
                            className={`font-data-sm text-data-sm ${
                              cand.dpsDeltaPositive
                                ? 'text-tertiary'
                                : isViolation
                                ? 'text-error'
                                : 'text-on-surface-variant'
                            }`}
                          >
                            {cand.dpsDelta}
                          </span>
                        </div>

                        {!isCurrent && !isViolation && (
                          <button
                            type="button"
                            onClick={() => setSelectedWeaponId(cand.id)}
                            className="px-space-sm py-1 rounded bg-surface-container-highest hover:bg-surface-container-high text-on-surface font-data-sm text-data-sm transition-colors cursor-pointer border border-surface-container-high/40"
                          >
                            {cand.id === 'scimitar' ? 'Try Swap' : 'Swap'}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* ChatGPT MCP Contextual Advisory Integration */}
            <div className="bg-surface-container-lowest rounded-lg p-space-sm flex items-center justify-between mt-space-xs border border-surface-container-high/30">
              <div className="flex items-center gap-space-sm">
                <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-primary shrink-0 border border-primary/20">
                  <span className="material-symbols-outlined text-[18px]">smart_toy</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-title-md text-title-md text-on-surface font-semibold">
                    Discuss Whip vs Fang with ChatGPT
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">
                    Examine whether liquidating bank items for Fang is +GP/hr optimal.
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  onOpenAdvisor?.('Examine whether liquidating bank items for Fang is +GP/hr optimal.')
                }
                className="px-space-md py-1 rounded bg-surface-container hover:bg-surface-container-high text-primary font-title-md text-title-md transition-colors shrink-0 cursor-pointer border border-primary/20"
              >
                Prompt MCP
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
