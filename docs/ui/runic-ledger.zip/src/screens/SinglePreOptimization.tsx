import React, { useState, useEffect } from 'react';
import { ScreenType, TransitionType } from '../types';

interface SinglePreOptimizationProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: (prompt?: string) => void;
}

export const SinglePreOptimization: React.FC<SinglePreOptimizationProps> = ({
  onNavigate,
  onOpenAdvisor,
}) => {
  const [budget, setBudget] = useState<number>(5000000);
  const [discipline, setDiscipline] = useState<'melee' | 'ranged' | 'magic'>('melee');
  const [objective, setObjective] = useState<'max-dps' | 'max-hit' | 'accuracy' | 'survivability'>(
    'max-dps'
  );
  const [whatIfOpen, setWhatIfOpen] = useState<boolean>(false);
  const [enforceLimits, setEnforceLimits] = useState<boolean>(true);
  const [prioritizeBank, setPrioritizeBank] = useState<boolean>(true);
  const [banDegradables, setBanDegradables] = useState<boolean>(false);

  // Spacebar listener to run optimization
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && e.target instanceof HTMLElement) {
        if (e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
          e.preventDefault();
          onNavigate('single-post', 'push');
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onNavigate]);

  const handleRunOptimization = () => {
    onNavigate('single-post', 'push');
  };

  return (
    <div className="flex flex-col w-full p-space-md lg:p-space-lg gap-space-md max-w-[1880px] mx-auto select-none">
      {/* Top Context Sub-Header Bar */}
      <div className="w-full bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-wrap items-center justify-between gap-space-md border border-surface-container-high/40">
        <div className="flex items-center gap-space-md">
          <div className="w-10 h-10 rounded-lg bg-surface-container-high flex items-center justify-center text-primary shadow-sm border border-primary/20">
            <span className="material-symbols-outlined text-[24px]">terminal</span>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-space-sm">
              <span className="font-label-caps text-label-caps text-primary uppercase tracking-widest">
                Protocol 01 // Baseline State
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-tertiary animate-ping"></span>
              <span className="font-data-sm text-data-sm text-tertiary uppercase">Bridge Stable</span>
            </div>
            <span className="font-headline-sm text-headline-sm text-on-surface font-bold tracking-tight">
              MODE: SINGLE-STYLE{' '}
              <span className="text-on-surface-variant font-normal">
                // BASELINE INSPECTION (Ready to calculate optimal equipment)
              </span>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-space-lg">
          <div className="hidden md:flex items-center gap-space-md bg-surface-container-lowest px-space-md py-space-xs rounded-lg border border-surface-container-high/40">
            <div className="flex flex-col text-right">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                Search Combinations
              </span>
              <span className="font-data-sm text-data-sm text-on-surface font-semibold">
                14,288 Variants Filtered
              </span>
            </div>
            <div className="h-6 w-px bg-surface-container-highest"></div>
            <div className="flex flex-col text-right">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">Latency</span>
              <span className="font-data-sm text-data-sm text-secondary">0.6s Sync</span>
            </div>
          </div>

          {/* Prominent Glowing Gold CTA Button with exact id="run-optimization-btn" */}
          <button
            className="relative group flex items-center gap-space-sm px-space-xl py-space-md bg-primary hover:bg-primary-container text-on-primary font-title-md text-title-md font-bold rounded-lg shadow-xl transition-all duration-200 transform hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
            id="run-optimization-btn"
            onClick={handleRunOptimization}
            type="button"
          >
            <span className="absolute -inset-0.5 rounded-lg bg-primary/40 blur group-hover:blur-md transition-all"></span>
            <span className="relative flex items-center gap-space-sm">
              <span className="material-symbols-outlined text-[20px] text-on-primary animate-bounce">bolt</span>
              <span>Run Optimization</span>
              <span className="px-space-xs py-0.5 rounded bg-surface-container-lowest/30 text-on-primary font-data-sm text-data-sm uppercase font-mono">
                [Space]
              </span>
            </span>
          </button>
        </div>
      </div>

      {/* Primary Three-Column Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-space-md items-start">
        {/* Left Column (Optimization Configuration) */}
        <div className="lg:col-span-4 xl:col-span-3 flex flex-col gap-space-md">
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            <div className="flex items-center justify-between pb-space-xs">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-primary text-[18px]">tune</span>
                <span className="font-label-caps text-label-caps text-on-surface font-bold uppercase tracking-wider">
                  Optimization Parameters
                </span>
              </div>
              <span className="font-data-sm text-data-sm text-on-surface-variant uppercase">CONFIG // v4.2</span>
            </div>

            {/* Encounter Summary Card */}
            <div className="bg-surface-container rounded-lg p-space-md flex flex-col gap-space-xs relative overflow-hidden border border-surface-container-high/40">
              <div className="absolute right-0 top-0 w-24 h-24 bg-error/5 rounded-full blur-xl pointer-events-none"></div>
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-label-caps text-secondary uppercase tracking-wider">
                  Encounter Target
                </span>
                <span className="px-space-xs py-0.5 rounded bg-error/20 text-error font-data-sm text-data-sm font-semibold">
                  Lvl 732
                </span>
              </div>
              <div className="flex items-baseline justify-between mt-1">
                <span className="font-headline-sm text-headline-sm text-on-surface font-bold">Vorkath</span>
                <span className="font-data-sm text-data-sm text-on-surface-variant font-medium">
                  750 HP · Draconic/Undead
                </span>
              </div>
              <div className="grid grid-cols-3 gap-space-xs mt-space-xs bg-surface-container-lowest p-space-xs rounded border border-surface-container-high/40">
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Defense
                  </span>
                  <span className="font-data-md text-data-md text-on-surface">214</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Slash Def
                  </span>
                  <span className="font-data-md text-data-md text-primary">+26</span>
                </div>
                <div className="flex flex-col">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Hazard
                  </span>
                  <span className="font-data-md text-data-md text-error">Dragonfire</span>
                </div>
              </div>
              <div className="flex items-center gap-space-xs mt-space-xs text-error font-data-sm text-data-sm">
                <span className="material-symbols-outlined text-[14px]">local_fire_department</span>
                <span>Dragonfire Mech Active: Shield Slot Hard-Constrained</span>
              </div>
            </div>

            {/* Combat Discipline Selection */}
            <div className="flex flex-col gap-space-xs">
              <label className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Combat Discipline
              </label>
              <div className="grid grid-cols-3 gap-space-xs bg-surface-container-lowest p-space-xs rounded-lg border border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setDiscipline('melee')}
                  className={`py-space-xs px-space-sm rounded font-title-md text-title-md flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                    discipline === 'melee'
                      ? 'bg-surface-container-high text-primary font-bold shadow-sm'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[16px]">swords</span>
                  <span>Melee</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDiscipline('ranged')}
                  className={`py-space-xs px-space-sm rounded font-title-md text-title-md flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                    discipline === 'ranged'
                      ? 'bg-surface-container-high text-primary font-bold shadow-sm'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[16px]">adjust</span>
                  <span>Ranged</span>
                </button>
                <button
                  type="button"
                  onClick={() => setDiscipline('magic')}
                  className={`py-space-xs px-space-sm rounded font-title-md text-title-md flex items-center justify-center gap-1 transition-colors cursor-pointer ${
                    discipline === 'magic'
                      ? 'bg-surface-container-high text-primary font-bold shadow-sm'
                      : 'text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[16px]">auto_fix_high</span>
                  <span>Magic</span>
                </button>
              </div>
              <div className="flex items-center justify-between px-space-xs mt-1">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                  Attack Style:
                </span>
                <span className="font-data-sm text-data-sm text-primary">
                  {discipline === 'melee'
                    ? 'Aggressive (Flick / Slash)'
                    : discipline === 'ranged'
                    ? 'Rapid (Dragonbane / Toxic)'
                    : 'Autocast (Standard / Ancient)'}
                </span>
              </div>
            </div>

            {/* Optimization Objective */}
            <div className="flex flex-col gap-space-xs">
              <label className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Optimization Objective
              </label>
              <div className="grid grid-cols-2 gap-space-xs">
                <div
                  onClick={() => setObjective('max-dps')}
                  className={`flex items-center gap-space-sm p-space-sm rounded cursor-pointer transition-colors ${
                    objective === 'max-dps'
                      ? 'bg-surface-container-high text-primary border border-primary/30'
                      : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[18px]">electric_bolt</span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md font-bold leading-none">Max DPS</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant text-[10px]">
                      Optimal kill velocity
                    </span>
                  </div>
                </div>
                <div
                  onClick={() => setObjective('max-hit')}
                  className={`flex items-center gap-space-sm p-space-sm rounded cursor-pointer transition-colors ${
                    objective === 'max-hit'
                      ? 'bg-surface-container-high text-primary border border-primary/30'
                      : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[18px]">sports_martial_arts</span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md font-semibold leading-none">Max Hit</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant text-[10px]">
                      Peak damage ceiling
                    </span>
                  </div>
                </div>
                <div
                  onClick={() => setObjective('accuracy')}
                  className={`flex items-center gap-space-sm p-space-sm rounded cursor-pointer transition-colors ${
                    objective === 'accuracy'
                      ? 'bg-surface-container-high text-primary border border-primary/30'
                      : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[18px]">gps_fixed</span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md font-semibold leading-none">Accuracy</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant text-[10px]">
                      Hit chance focus
                    </span>
                  </div>
                </div>
                <div
                  onClick={() => setObjective('survivability')}
                  className={`flex items-center gap-space-sm p-space-sm rounded cursor-pointer transition-colors ${
                    objective === 'survivability'
                      ? 'bg-surface-container-high text-primary border border-primary/30'
                      : 'bg-surface-container text-on-surface-variant hover:text-on-surface'
                  }`}
                >
                  <span className="material-symbols-outlined text-[18px]">health_and_safety</span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md font-semibold leading-none">Survivability</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant text-[10px]">
                      Prayer &amp; Def stats
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Acquisition Budget Slider */}
            <div className="flex flex-col gap-space-xs bg-surface-container rounded-lg p-space-md border border-surface-container-high/40">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-label-caps text-on-surface uppercase">
                  Additional Budget:
                </span>
                <span className="font-data-md text-data-md text-primary font-bold" id="budget-value">
                  {budget.toLocaleString('en-US')} GP
                </span>
              </div>
              <input
                className="w-full h-1.5 bg-surface-container-lowest rounded-lg appearance-none cursor-pointer accent-primary mt-2"
                id="budget-slider"
                max="25000000"
                min="0"
                step="500000"
                type="range"
                value={budget}
                onChange={(e) => setBudget(parseInt(e.target.value, 10))}
              />
              <div className="flex justify-between font-data-sm text-data-sm text-on-surface-variant mt-1">
                <span>0 GP (Bank Only)</span>
                <span>10M</span>
                <span>25M (Cap)</span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant mt-1 leading-snug">
                Calculates new GE purchases only; reuses owned bank items at{' '}
                <span className="text-tertiary font-semibold font-mono">0 GP</span> out-of-pocket cost.
              </p>
            </div>

            {/* Restrictions Checklist */}
            <div className="flex flex-col gap-space-xs">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Account Constraints
              </span>
              <div className="flex flex-col gap-space-xs">
                <label className="flex items-start gap-space-sm bg-surface-container p-space-xs rounded cursor-pointer group border border-surface-container-high/30">
                  <input
                    checked={enforceLimits}
                    onChange={(e) => setEnforceLimits(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded bg-surface-container-lowest accent-primary cursor-pointer"
                    type="checkbox"
                  />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface group-hover:text-primary transition-colors">
                      Enforce Account Skill &amp; Quest Limits
                    </span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">
                      Iron_Vann: 70 Atk · 70 Str · 70 Def · RFD Done
                    </span>
                  </div>
                </label>
                <label className="flex items-start gap-space-sm bg-surface-container p-space-xs rounded cursor-pointer group border border-surface-container-high/30">
                  <input
                    checked={prioritizeBank}
                    onChange={(e) => setPrioritizeBank(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded bg-surface-container-lowest accent-primary cursor-pointer"
                    type="checkbox"
                  />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface group-hover:text-primary transition-colors">
                      Prioritize Bank &amp; Vault Inventory
                    </span>
                    <span className="font-data-sm text-data-sm text-tertiary">
                      Zero-cost prioritization on 8 detected cache items
                    </span>
                  </div>
                </label>
                <label className="flex items-start gap-space-sm bg-surface-container p-space-xs rounded cursor-pointer group border border-surface-container-high/30">
                  <input
                    checked={banDegradables}
                    onChange={(e) => setBanDegradables(e.target.checked)}
                    className="mt-1 w-4 h-4 rounded bg-surface-container-lowest accent-primary cursor-pointer"
                    type="checkbox"
                  />
                  <div className="flex flex-col">
                    <span className="font-body-md text-body-md text-on-surface group-hover:text-primary transition-colors">
                      Ban Degradables
                    </span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">
                      Excludes Barrows armor, tentacle whip &amp; scythe charges
                    </span>
                  </div>
                </label>
              </div>
            </div>

            {/* Collapsible What-If Section */}
            <div className="border-t border-surface-container-high pt-space-xs flex flex-col">
              <button
                className="flex items-center justify-between py-space-xs text-on-surface-variant hover:text-primary transition-colors w-full cursor-pointer"
                id="what-if-toggle"
                onClick={() => setWhatIfOpen(!whatIfOpen)}
                type="button"
              >
                <div className="flex items-center gap-space-xs font-label-caps text-label-caps uppercase">
                  <span className="material-symbols-outlined text-[16px]">science</span>
                  <span>What-If Scenario Simulation</span>
                </div>
                <span
                  className={`material-symbols-outlined text-[16px] transition-transform ${
                    whatIfOpen ? 'rotate-180' : ''
                  }`}
                  id="what-if-icon"
                >
                  expand_more
                </span>
              </button>
              {whatIfOpen && (
                <div
                  className="flex flex-col gap-space-xs pt-space-xs bg-surface-container-lowest p-space-sm rounded border border-surface-container-high/40 mt-1"
                  id="what-if-panel"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-body-sm text-body-sm text-on-surface">Target Level Simulation</span>
                    <span className="font-data-sm text-data-sm text-primary">+5 Str (Lvl 75)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="font-body-sm text-body-sm text-on-surface">Prayer Override</span>
                    <span className="font-data-sm text-data-sm text-secondary">Piety [Lvl 70]</span>
                  </div>
                  <span className="font-data-sm text-data-sm text-on-surface-variant italic">
                    When executed, computes differential comparison against current 70 Str baseline.
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Center Column (Equipment Grid — Currently Equipped Baseline) */}
        <div className="lg:col-span-8 xl:col-span-6 flex flex-col gap-space-md">
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            {/* Section Header */}
            <div className="flex flex-wrap items-center justify-between gap-space-sm pb-space-xs">
              <div>
                <div className="flex items-center gap-space-xs">
                  <span className="material-symbols-outlined text-secondary text-[20px]">person_pin</span>
                  <h2 className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    Current Account Loadout
                  </h2>
                </div>
                <p className="font-body-sm text-body-sm text-on-surface-variant">
                  Baseline equipment currently worn by{' '}
                  <span className="text-on-surface font-semibold">Iron_Vann</span>. 11 active slots tracked
                  via RuneLite.
                </p>
              </div>
              <div className="flex items-center gap-space-xs bg-surface-container-highest px-space-sm py-0.5 rounded border border-surface-container-high/40">
                <span className="material-symbols-outlined text-tertiary text-[14px]">sync</span>
                <span className="font-data-sm text-data-sm text-tertiary">11/11 Slots Synced</span>
              </div>
            </div>

            {/* 11-Slot OSRS Paperdoll Layout (Stone-Cut Recessed Grid) */}
            <div className="bg-surface-container-lowest rounded-xl p-space-md flex flex-col items-center justify-center relative overflow-hidden border border-surface-container-high/30 min-h-[460px]">
              {/* Background Arcane Rune Watermark */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
                <span className="material-symbols-outlined text-[360px] text-primary">shield_person</span>
              </div>

              {/* Paperdoll Slots Arrangement */}
              <div className="w-full max-w-md flex flex-col gap-space-xs z-10">
                {/* Row 1: Head Slot */}
                <div className="flex justify-center">
                  <div className="w-44 bg-surface-container rounded-lg p-space-xs shadow-inner flex items-center gap-space-sm group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="w-10 h-10 rounded bg-surface-container-lowest flex items-center justify-center text-primary shrink-0 shadow-sm">
                      <span className="material-symbols-outlined text-[22px]">military_tech</span>
                    </div>
                    <div className="flex flex-col min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                          Head
                        </span>
                        <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                          Equipped
                        </span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Slayer Helm (i)
                      </span>
                      <span className="font-data-sm text-data-sm text-on-surface-variant truncate">
                        +3 Slash · +30 Def
                      </span>
                    </div>
                  </div>
                </div>

                {/* Row 2: Cape / Neck / Ammo */}
                <div className="grid grid-cols-3 gap-space-xs">
                  {/* Cape */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Cape
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-primary-fixed-dim shrink-0">
                        <span className="material-symbols-outlined text-[18px]">local_fire_department</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Fire Cape
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary truncate">+4 Str · +11 Def</span>
                  </div>

                  {/* Neck */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors relative border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Neck
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-primary shrink-0">
                        <span className="material-symbols-outlined text-[18px]">diamond</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Amulet of Glory
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-data-sm text-data-sm text-on-surface-variant truncate">+6 Str</span>
                      <span
                        className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"
                        title="Opportunity available"
                      ></span>
                    </div>
                  </div>

                  {/* Ammo */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Ammo
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-secondary shrink-0">
                        <span className="material-symbols-outlined text-[18px]">workspace_premium</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Rada's Blessing 2
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-on-surface-variant truncate">+1 Prayer</span>
                  </div>
                </div>

                {/* Row 3: Weapon / Body / Shield */}
                <div className="grid grid-cols-3 gap-space-xs">
                  {/* Weapon */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Weapon
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-error shrink-0">
                        <span className="material-symbols-outlined text-[18px]">sports_kabaddi</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Dragon Scimitar
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary truncate">+67 Slash · +66 Str</span>
                  </div>

                  {/* Body */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Body
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-primary shrink-0">
                        <span className="material-symbols-outlined text-[18px]">shield</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Fighter Torso
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary truncate">+4 Str · +85 Slash Def</span>
                  </div>

                  {/* Shield (Mandatory constraint) */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Shield
                      </span>
                      <span className="px-1 py-0.2 rounded bg-error/20 text-error font-data-sm text-data-sm text-[10px] flex items-center gap-0.5">
                        <span className="material-symbols-outlined text-[10px]">lock</span> Mandatory
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-error shrink-0">
                        <span className="material-symbols-outlined text-[18px]">security</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Anti-Dragon Shield
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-error truncate">Fire Immunity Active</span>
                  </div>
                </div>

                {/* Row 4: Legs Slot */}
                <div className="flex justify-center">
                  <div className="w-44 bg-surface-container rounded-lg p-space-xs shadow-inner flex items-center gap-space-sm group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="w-10 h-10 rounded bg-surface-container-lowest flex items-center justify-center text-secondary shrink-0">
                      <span className="material-symbols-outlined text-[20px]">airline_seat_legroom_reduced</span>
                    </div>
                    <div className="flex flex-col min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                          Legs
                        </span>
                        <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                          Equipped
                        </span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Rune Platelegs
                      </span>
                      <span className="font-data-sm text-data-sm text-primary font-medium truncate">
                        +0 Str · Upgrade Cand.
                      </span>
                    </div>
                  </div>
                </div>

                {/* Row 5: Hands / Boots / Ring */}
                <div className="grid grid-cols-3 gap-space-xs">
                  {/* Hands */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Hands
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-on-surface-variant shrink-0">
                        <span className="material-symbols-outlined text-[18px]">back_hand</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Barrows Gloves
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary truncate">+12 Slash · +12 Str</span>
                  </div>

                  {/* Boots */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Boots
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-on-surface-variant shrink-0">
                        <span className="material-symbols-outlined text-[18px]">footprint</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Climbing Boots
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary font-medium truncate">
                      +2 Str · Upgrade Cand.
                    </span>
                  </div>

                  {/* Ring */}
                  <div className="bg-surface-container rounded-lg p-space-xs shadow-inner flex flex-col justify-between group hover:bg-surface-container-high transition-colors border border-surface-container-high/30">
                    <div className="flex items-center justify-between">
                      <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[9px]">
                        Ring
                      </span>
                      <span className="px-1 py-0.2 rounded bg-secondary/15 text-secondary font-data-sm text-data-sm text-[10px]">
                        Equipped
                      </span>
                    </div>
                    <div className="flex items-center gap-space-xs my-1">
                      <div className="w-8 h-8 rounded bg-surface-container-lowest flex items-center justify-center text-primary shrink-0">
                        <span className="material-symbols-outlined text-[18px]">trip_origin</span>
                      </div>
                      <span className="font-title-md text-title-md text-on-surface font-semibold truncate">
                        Berserker Ring (i)
                      </span>
                    </div>
                    <span className="font-data-sm text-data-sm text-primary truncate">+8 Str Bonus</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Baseline Combat Telemetry Strip */}
            <div className="bg-surface-container rounded-xl p-space-md flex flex-col gap-space-sm border border-surface-container-high/40">
              <div className="flex items-center justify-between">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                  Baseline Combat Telemetry (Pre-Run)
                </span>
                <span className="font-data-sm text-data-sm text-secondary">Formula: CalcOSRS v3.8</span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-space-xs">
                <div className="bg-surface-container-lowest p-space-sm rounded-lg flex flex-col border border-surface-container-high/30">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Effective DPS
                  </span>
                  <span className="font-data-lg text-data-lg text-primary font-bold">5.66</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">Baseline Anchor</span>
                </div>
                <div className="bg-surface-container-lowest p-space-sm rounded-lg flex flex-col border border-surface-container-high/30">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Max Hit
                  </span>
                  <span className="font-data-lg text-data-lg text-on-surface font-bold">36</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">Super Str Ingested</span>
                </div>
                <div className="bg-surface-container-lowest p-space-sm rounded-lg flex flex-col border border-surface-container-high/30">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Accuracy
                  </span>
                  <span className="font-data-lg text-data-lg text-secondary font-bold">55.8%</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">vs 214 Def +26</span>
                </div>
                <div className="bg-surface-container-lowest p-space-sm rounded-lg flex flex-col border border-surface-container-high/30">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Attack Speed
                  </span>
                  <span className="font-data-lg text-data-lg text-on-surface font-bold">4 ticks</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">2.4s Cycle</span>
                </div>
                <div className="bg-surface-container-lowest p-space-sm rounded-lg flex flex-col border border-surface-container-high/30">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase text-[10px]">
                    Current Cost
                  </span>
                  <span className="font-data-lg text-data-lg text-tertiary font-bold">0 GP</span>
                  <span className="font-data-sm text-data-sm text-tertiary">100% Owned</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (Optimization Readiness & Potential Preview) */}
        <div className="lg:col-span-12 xl:col-span-3 flex flex-col gap-space-md">
          {/* Engine Status Card */}
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            <div className="flex items-center justify-between pb-space-xs">
              <div className="flex items-center gap-space-sm">
                <span className="material-symbols-outlined text-secondary text-[20px]">analytics</span>
                <span className="font-label-caps text-label-caps text-on-surface font-bold uppercase tracking-wider">
                  Optimizer Engine
                </span>
              </div>
              <span className="px-space-xs py-0.5 rounded bg-surface-container-highest text-secondary font-data-sm text-data-sm font-mono border border-secondary/20">
                STANDBY
              </span>
            </div>
            <div className="bg-surface-container rounded-lg p-space-md flex flex-col gap-space-sm border border-surface-container-high/30">
              <div className="flex items-center gap-space-sm">
                <span className="w-2.5 h-2.5 rounded-full bg-secondary animate-pulse"></span>
                <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                  Awaiting Execution
                </span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant leading-relaxed">
                All parameters primed. The solver is ready to evaluate optimal gear combinations within your{' '}
                {(budget / 1000000).toFixed(1)}M GP budget threshold.
              </p>
            </div>

            {/* Pre-Flight Telemetry Findings */}
            <div className="flex flex-col gap-space-xs">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Pre-Optimization Analysis
              </span>
              <div className="space-y-space-xs">
                <div className="bg-surface-container p-space-sm rounded-lg flex items-start gap-space-sm border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-tertiary text-[18px] shrink-0 mt-0.5">
                    storefront
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface font-medium">
                      8 Upgrade Candidates Found
                    </span>
                    <span className="font-body-sm text-body-sm text-on-surface-variant">
                      Grand Exchange catalog indexed within {(budget / 1000000).toFixed(1)}M GP budget limit.
                    </span>
                  </div>
                </div>
                <div className="bg-surface-container p-space-sm rounded-lg flex items-start gap-space-sm border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-error text-[18px] shrink-0 mt-0.5">
                    lock_clock
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface font-medium">
                      Anti-Dragon Shield Locked
                    </span>
                    <span className="font-body-sm text-body-sm text-on-surface-variant">
                      Mandatory to prevent 100% dragonfire damage pass-through.
                    </span>
                  </div>
                </div>
                <div className="bg-surface-container p-space-sm rounded-lg flex items-start gap-space-sm border border-surface-container-high/30">
                  <span className="material-symbols-outlined text-primary text-[18px] shrink-0 mt-0.5">
                    inventory
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface font-medium">
                      Vault Cache Leveraged
                    </span>
                    <span className="font-body-sm text-body-sm text-on-surface-variant">
                      Detected <span className="text-primary font-semibold">Amulet of Fury</span> in bank cache,
                      ready to slot at 0 GP expense.
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Big Secondary Run Action CTA with exact id="run-optimization-btn-2" */}
            <div className="flex flex-col gap-space-xs mt-space-xs">
              <button
                className="w-full py-space-md px-space-lg bg-primary hover:bg-primary-container text-on-primary font-title-md text-title-md font-bold rounded-lg shadow-lg flex items-center justify-center gap-space-sm transition-all duration-200 cursor-pointer"
                id="run-optimization-btn-2"
                onClick={handleRunOptimization}
                type="button"
              >
                <span className="material-symbols-outlined text-[20px]">bolt</span>
                <span>Run Optimization</span>
                <span className="text-on-primary/70 font-data-sm text-data-sm font-mono">[Space]</span>
              </button>
              <div className="flex items-center justify-between text-on-surface-variant px-space-xs">
                <span className="font-data-sm text-data-sm">Estimated runtime: ~120ms</span>
                <span className="font-data-sm text-data-sm text-tertiary">Deterministic Exact</span>
              </div>
            </div>

            {/* MCP Quick Prompt Assist Card */}
            <div className="bg-surface-container-lowest rounded-lg p-space-sm flex flex-col gap-space-xs mt-space-xs border border-surface-container-high/40">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-space-xs text-primary">
                  <span className="material-symbols-outlined text-[16px]">smart_toy</span>
                  <span className="font-label-caps text-label-caps uppercase font-bold">
                    MCP Intelligence Bridge
                  </span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">GPT-4o</span>
              </div>
              <p className="font-body-sm text-body-sm text-on-surface-variant">
                Need advice before computing? Query the assistant with your current Iron_Vann bank state.
              </p>
              <button
                type="button"
                onClick={() => onOpenAdvisor?.('Ask ChatGPT what to prioritize before running optimization')}
                className="mt-1 w-full text-left py-space-xs px-space-sm rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-data-sm text-data-sm flex items-center justify-between group transition-colors cursor-pointer border border-surface-container-high/30"
              >
                <span className="truncate">"Ask ChatGPT what to prioritize before running optimization"</span>
                <span className="material-symbols-outlined text-[16px] text-primary group-hover:translate-x-0.5 transition-transform">
                  send
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
