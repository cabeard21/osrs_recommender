import React from 'react';
import { ScreenType, TransitionType } from '../types';

interface MultiSideBySideProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: (prompt?: string) => void;
}

export const MultiSideBySide: React.FC<MultiSideBySideProps> = ({ onNavigate }) => {
  const handleInteractiveSwitchingClick = (e: React.MouseEvent) => {
    e.preventDefault();
    // Spec: Element (xpath: //a[@data-path='interactive-switching-view']) → Multi-Style Optimizer — Interactive Switching View (push transition)
    onNavigate('multi-interactive', 'push');
  };

  return (
    <div className="flex flex-col w-full p-space-lg space-y-space-md select-none">
      {/* Sub-Header Context Bar */}
      <div className="w-full bg-surface-container-low rounded-lg p-space-md shadow-md flex flex-col xl:flex-row items-start xl:items-center justify-between gap-space-md border border-surface-container-high/40">
        <div className="flex flex-wrap items-center gap-space-lg">
          <div className="flex items-center gap-space-sm">
            <span className="w-2.5 h-2.5 rounded-full bg-secondary animate-ping"></span>
            <div className="flex flex-col">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                Encounter Target
              </span>
              <span className="font-headline-sm text-headline-sm text-on-surface flex items-center gap-space-xs">
                Vorkath{' '}
                <span className="font-data-sm text-data-sm text-secondary bg-surface-container px-space-xs py-0.5 rounded border border-secondary/20">
                  LVL 732 · DRACONIC
                </span>
              </span>
            </div>
          </div>
          <div className="h-8 w-px bg-surface-container-high hidden md:block"></div>
          <div className="flex flex-col">
            <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
              Multi-Style Matrix
            </span>
            <div className="flex items-center gap-space-xs font-title-md text-title-md text-on-surface">
              <span className="text-primary font-bold">Melee (Slash Aggressive)</span>
              <span className="material-symbols-outlined text-[16px] text-tertiary">sync_alt</span>
              <span className="text-secondary font-bold">Ranged (Rapid / Toxic)</span>
            </div>
          </div>
          <div className="h-8 w-px bg-surface-container-high hidden md:block"></div>
          {/* Tactical Swap Limit Indicator */}
          <div className="flex flex-col min-w-[200px]">
            <div className="flex items-center justify-between">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                Tactical Swap Limit
              </span>
              <span className="font-data-sm text-data-sm text-primary font-bold">4 / 4 SLOTS USED</span>
            </div>
            <div className="grid grid-cols-4 gap-1 mt-1.5 h-2">
              <div className="bg-primary rounded-sm shadow-[0_0_6px_rgba(240,191,92,0.4)]"></div>
              <div className="bg-primary rounded-sm shadow-[0_0_6px_rgba(240,191,92,0.4)]"></div>
              <div className="bg-primary rounded-sm shadow-[0_0_6px_rgba(240,191,92,0.4)]"></div>
              <div className="bg-primary rounded-sm shadow-[0_0_6px_rgba(240,191,92,0.4)]"></div>
            </div>
          </div>
        </div>

        {/* Incremental Spend Metric */}
        <div className="flex items-center gap-space-lg w-full xl:w-auto justify-between xl:justify-end bg-surface-container px-space-md py-space-sm rounded border border-surface-container-high/30">
          <div className="flex flex-col min-w-[170px]">
            <div className="flex items-center justify-between text-on-surface">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                Incremental Spend
              </span>
              <span className="font-data-sm text-data-sm text-tertiary font-bold">3.45M / 5.00M GP</span>
            </div>
            <div className="w-full bg-surface-container-lowest h-1.5 rounded-full mt-1.5 overflow-hidden">
              <div className="bg-tertiary h-full rounded-full" style={{ width: '69%' }}></div>
            </div>
          </div>
          <div className="flex items-center gap-space-xs text-tertiary font-data-sm text-data-sm bg-surface-container-lowest px-space-sm py-1 rounded border border-tertiary/20">
            <span className="material-symbols-outlined text-[16px]">savings</span>
            <span>+1.55M Headroom</span>
          </div>
        </div>
      </div>

      {/* Matrix Alignment Strip & Visual Legend */}
      <div className="w-full bg-surface-container px-space-md py-space-xs rounded flex flex-wrap items-center justify-between text-on-surface gap-space-sm shadow-sm border border-surface-container-high/40">
        <div className="flex items-center gap-space-md">
          <span className="font-label-caps text-label-caps text-primary tracking-widest uppercase flex items-center gap-1">
            <span className="material-symbols-outlined text-[15px]">view_column</span> Matrix Alignment
          </span>
          <div className="h-4 w-px bg-surface-container-high"></div>
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            Core Persistence:{' '}
            <span className="font-data-sm text-data-sm text-tertiary font-semibold">7 Slots (0 Swaps)</span>
          </span>
          <span className="text-surface-container-highest">/</span>
          <span className="font-body-sm text-body-sm text-on-surface-variant">
            Active Swaps:{' '}
            <span className="font-data-sm text-data-sm text-primary font-semibold">4 Slots (Hard Cap)</span>
          </span>
        </div>
        <div className="flex items-center gap-space-lg font-data-sm text-data-sm">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-tertiary">link</span>
            <span className="text-on-surface">Shared Core (Invariant)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-[16px] text-primary">bolt</span>
            <span className="text-on-surface">Tactical Swap Item (Allocated)</span>
          </div>
          <div className="flex items-center gap-1.5 opacity-60">
            <span className="material-symbols-outlined text-[16px] text-error">cancel</span>
            <span className="text-on-surface-variant">Unselected Slot Swap</span>
          </div>
        </div>
      </div>

      {/* Dual Side-by-Side Equipment Configuration Grids */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-space-md">
        {/* Column A: Melee Stance */}
        <div className="flex flex-col bg-surface-container-low rounded-lg p-space-md shadow-md space-y-space-md relative overflow-hidden border border-surface-container-high/30">
          <div className="absolute -top-12 -left-12 w-48 h-48 bg-primary/5 rounded-full blur-2xl pointer-events-none"></div>

          {/* Column Header & Telemetry */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm pb-space-sm bg-surface-container-lowest p-space-md rounded border border-surface-container-high/30">
            <div className="flex items-center gap-space-sm">
              <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center text-primary font-bold">
                <span className="material-symbols-outlined text-[20px]">colorize</span>
              </div>
              <div>
                <span className="font-headline-sm text-headline-sm text-primary font-bold tracking-tight">
                  Setup 1: Melee Stance
                </span>
                <span className="block font-data-sm text-data-sm text-on-surface-variant">
                  Main Hand: Abyssal Whip [Slash Aggressive]
                </span>
              </div>
            </div>
            <div className="flex items-center gap-space-xs font-data-sm text-data-sm bg-surface-container px-space-md py-space-xs rounded shadow-inner border border-surface-container-high/40">
              <span className="text-primary font-bold text-headline-sm">6.84</span>
              <span className="text-on-surface-variant text-label-caps uppercase">eDPS</span>
              <div className="h-3 w-px bg-surface-container-highest mx-1"></div>
              <span className="text-on-surface">
                Max: <span className="text-primary font-semibold">42</span>
              </span>
              <span className="text-surface-container-highest">·</span>
              <span className="text-on-surface">
                Acc: <span className="text-primary font-semibold">64.2%</span>
              </span>
              <span className="text-surface-container-highest">·</span>
              <span className="text-on-surface-variant">4t (2.4s)</span>
            </div>
          </div>

          {/* Paperdoll & Equipment Matrix Melee */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-space-md items-start">
            {/* OSRS Paperdoll Layout Melee (5 cols) */}
            <div className="md:col-span-5 bg-surface-container-lowest p-space-md rounded-lg flex flex-col items-center justify-center space-y-2 border border-surface-container-high/30">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider text-center">
                Paperdoll Configuration
              </span>
              <div className="grid grid-cols-3 gap-2 w-full max-w-[210px] py-space-xs">
                {/* Row 1: Head */}
                <div></div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Slayer Helmet (i) - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">smart_toy</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Slayer (i)
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div></div>

                {/* Row 2: Cape / Neck / Ammo */}
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Fire Cape - Swap Slot 1"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">shield</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Fire Cape
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 1"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Amulet of Fury - Swap Slot 2"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">circle</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Fury
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 2"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Rada's Blessing 2 - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">expand</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Rada's 2
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>

                {/* Row 3: Weapon / Body / Shield */}
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Abyssal Whip - Swap Slot 3"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">
                    sports_martial_arts
                  </span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Whip
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 3"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Fighter Torso - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">apparel</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Torso
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Anti-Dragon Shield - Swap Slot 4"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">security</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Anti-D Shield
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 4"
                  >
                    bolt
                  </span>
                </div>

                {/* Row 4: Legs */}
                <div></div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Obsidian Platelegs - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">
                    airline_seat_legroom_reduced
                  </span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Obsidian
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div></div>

                {/* Row 5: Gloves / Boots / Ring */}
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Barrows Gloves - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">front_hand</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Barrows
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Dragon Boots - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">snowshoeing</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    D Boots
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Berserker Ring (i) - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">album</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    B-Ring (i)
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-center gap-space-xs text-on-surface-variant font-data-sm text-[11px] pt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                <span>4 Swaps Required for Transition</span>
              </div>
            </div>

            {/* Slot Breakdown Ledger (7 cols) */}
            <div className="md:col-span-7 flex flex-col space-y-1">
              <div className="bg-surface-container-lowest px-space-sm py-1 rounded flex items-center justify-between font-label-caps text-[10px] text-on-surface-variant uppercase border border-surface-container-high/30">
                <span>Slot Assignment</span>
                <span>Allocated Gear Item</span>
                <span>Classification</span>
              </div>
              <div className="space-y-1 text-on-surface font-body-sm">
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Head</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Slayer Helmet (i)
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Cape</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Fire Cape
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 1
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Neck</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Amulet of Fury
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 2
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Ammo</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Rada's Blessing 2
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Weapon</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Abyssal Whip
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 3
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Body</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Fighter Torso
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Shield</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Anti-Dragon Shield
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 4
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Legs</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Obsidian Platelegs
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Hands</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Barrows Gloves
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Boots</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Dragon Boots
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Ring</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Berserker Ring (i)
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Column B: Ranged Stance */}
        <div className="flex flex-col bg-surface-container-low rounded-lg p-space-md shadow-md space-y-space-md relative overflow-hidden border border-surface-container-high/30">
          <div className="absolute -top-12 -left-12 w-48 h-48 bg-secondary/5 rounded-full blur-2xl pointer-events-none"></div>

          {/* Column Header & Telemetry */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm pb-space-sm bg-surface-container-lowest p-space-md rounded border border-surface-container-high/30">
            <div className="flex items-center gap-space-sm">
              <div className="w-8 h-8 rounded bg-secondary/20 flex items-center justify-center text-secondary font-bold">
                <span className="material-symbols-outlined text-[20px]">adjust</span>
              </div>
              <div>
                <span className="font-headline-sm text-headline-sm text-secondary font-bold tracking-tight">
                  Setup 2: Ranged Stance
                </span>
                <span className="block font-data-sm text-data-sm text-on-surface-variant">
                  Main Hand: Toxic Blowpipe [Rapid / Dragonbane]
                </span>
              </div>
            </div>
            <div className="flex items-center gap-space-xs font-data-sm text-data-sm bg-surface-container px-space-md py-space-xs rounded shadow-inner border border-surface-container-high/40">
              <span className="text-secondary font-bold text-headline-sm">7.12</span>
              <span className="text-on-surface-variant text-label-caps uppercase">eDPS</span>
              <div className="h-3 w-px bg-surface-container-highest mx-1"></div>
              <span className="text-on-surface">
                Max: <span className="text-secondary font-semibold">28</span>
              </span>
              <span className="text-surface-container-highest">·</span>
              <span className="text-on-surface">
                Acc: <span className="text-secondary font-semibold">69.4%</span>
              </span>
              <span className="text-surface-container-highest">·</span>
              <span className="text-on-surface-variant">2t (1.2s)</span>
            </div>
          </div>

          {/* Paperdoll & Equipment Matrix Ranged */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-space-md items-start">
            {/* OSRS Paperdoll Layout Ranged (5 cols) */}
            <div className="md:col-span-5 bg-surface-container-lowest p-space-md rounded-lg flex flex-col items-center justify-center space-y-2 border border-surface-container-high/30">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider text-center">
                Paperdoll Configuration
              </span>
              <div className="grid grid-cols-3 gap-2 w-full max-w-[210px] py-space-xs">
                {/* Row 1: Head */}
                <div></div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Slayer Helmet (i) - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">smart_toy</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Slayer (i)
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div></div>

                {/* Row 2: Cape / Neck / Ammo */}
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Ava's Accumulator - Swap Slot 1"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">backpack</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Ava's Acc
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 1"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Necklace of Anguish - Swap Slot 2"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">lens</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Anguish
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 2"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Rada's Blessing 2 - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">expand</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Rada's 2
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>

                {/* Row 3: Weapon / Body / Shield */}
                <div
                  className="aspect-square bg-surface-container-high rounded p-1 flex flex-col items-center justify-center relative group shadow-sm border border-primary/30"
                  title="Toxic Blowpipe - Swap Slot 3"
                >
                  <span className="material-symbols-outlined text-primary text-[20px]">air</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Blowpipe
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 3"
                  >
                    bolt
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Fighter Torso - Shared Core (Armor Preserved)"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">apparel</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Torso
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core (Armor Preserved)"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container-lowest rounded p-1 flex flex-col items-center justify-center relative group opacity-60 border border-surface-container-high/30"
                  title="Empty (Two-Handed) - Swap Slot 4"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[20px]">
                    do_not_disturb_on
                  </span>
                  <span className="font-data-sm text-[10px] text-on-surface-variant font-medium truncate w-full text-center">
                    2-Handed
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-primary absolute top-1 right-1"
                    title="Swap Slot 4 (Shield Dropped)"
                  >
                    bolt
                  </span>
                </div>

                {/* Row 4: Legs */}
                <div></div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Obsidian Platelegs - Shared Core (Armor Preserved)"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">
                    airline_seat_legroom_reduced
                  </span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Obsidian
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core (Armor Preserved)"
                  >
                    link
                  </span>
                </div>
                <div></div>

                {/* Row 5: Gloves / Boots / Ring */}
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Barrows Gloves - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">front_hand</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    Barrows
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Dragon Boots - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">snowshoeing</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    D Boots
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
                <div
                  className="aspect-square bg-surface-container rounded p-1 flex flex-col items-center justify-center relative group shadow-sm hover:bg-surface-container-high transition-colors border border-surface-container-high/30"
                  title="Berserker Ring (i) - Shared Core"
                >
                  <span className="material-symbols-outlined text-tertiary text-[20px]">album</span>
                  <span className="font-data-sm text-[10px] text-on-surface font-semibold truncate w-full text-center">
                    B-Ring (i)
                  </span>
                  <span
                    className="material-symbols-outlined text-[12px] text-tertiary absolute top-1 right-1"
                    title="Shared Core"
                  >
                    link
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-center gap-space-xs text-on-surface-variant font-data-sm text-[11px] pt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
                <span>Armor Retained from Melee Loadout</span>
              </div>
            </div>

            {/* Slot Breakdown Ledger (7 cols) */}
            <div className="md:col-span-7 flex flex-col space-y-1">
              <div className="bg-surface-container-lowest px-space-sm py-1 rounded flex items-center justify-between font-label-caps text-[10px] text-on-surface-variant uppercase border border-surface-container-high/30">
                <span>Slot Assignment</span>
                <span>Allocated Gear Item</span>
                <span>Classification</span>
              </div>
              <div className="space-y-1 text-on-surface font-body-sm">
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Head</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Slayer Helmet (i)
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Cape</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Ava's Accumulator
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 1
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Neck</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Necklace of Anguish
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 2
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Ammo</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Rada's Blessing 2
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Weapon</span>
                  <span className="font-data-md text-data-md text-primary font-medium truncate flex-1">
                    Toxic Blowpipe
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 3
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Body</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Fighter Torso{' '}
                    <span className="text-data-sm text-on-surface-variant">(Preserved)</span>
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container-high/80 border border-primary/20">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Shield</span>
                  <span className="font-data-md text-data-md text-on-surface-variant font-medium truncate flex-1 italic">
                    Empty (Two-Handed)
                  </span>
                  <span className="font-data-sm text-data-sm text-primary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                    <span className="material-symbols-outlined text-[13px]">bolt</span> Swap 4
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Legs</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Obsidian Platelegs{' '}
                    <span className="text-data-sm text-on-surface-variant">(Preserved)</span>
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Hands</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Barrows Gloves
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Boots</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Dragon Boots
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
                <div className="flex items-center justify-between px-space-sm py-1 rounded bg-surface-container/60 hover:bg-surface-container">
                  <span className="font-label-caps text-label-caps text-on-surface-variant w-16">Ring</span>
                  <span className="font-data-md text-data-md text-on-surface font-medium truncate flex-1">
                    Berserker Ring (i)
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary flex items-center gap-1 bg-surface-container-lowest px-1.5 py-0.5 rounded border border-tertiary/20">
                    <span className="material-symbols-outlined text-[13px]">link</span> Core
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Tradeoff & Swap Analysis Panel */}
      <div className="bg-surface-container-low rounded-lg p-space-md shadow-md space-y-space-md border border-surface-container-high/30">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm">
          <div className="flex items-center gap-space-sm">
            <span className="material-symbols-outlined text-primary text-[20px]">analytics</span>
            <span className="font-headline-sm text-headline-sm text-on-surface font-bold tracking-tight">
              4-Swap Optimization Tradeoff Analysis
            </span>
            <span className="font-data-sm text-data-sm text-on-surface-variant bg-surface-container px-space-sm py-0.5 rounded border border-surface-container-high/30">
              Heuristic: Knapsack Matrix / Min-Switch
            </span>
          </div>

          {/* Action Controls */}
          <div className="flex items-center gap-space-sm">
            <button
              className="px-space-md py-space-xs rounded bg-surface-container hover:bg-surface-container-high text-on-surface font-title-md text-title-md flex items-center gap-1.5 transition-colors cursor-pointer border border-surface-container-high/40"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px] text-primary">autorenew</span>
              <span>Re-run Multi-Style Optimizer</span>
            </button>

            {/* EXACT MATCH FOR XPATH:
                //a[@data-path='interactive-switching-view']
            */}
            <a
              className="px-space-md py-space-xs rounded bg-primary hover:bg-primary-container text-on-primary font-title-md text-title-md flex items-center gap-1.5 shadow-sm transition-colors cursor-pointer font-bold"
              data-path="interactive-switching-view"
              href="#"
              onClick={handleInteractiveSwitchingClick}
            >
              <span>Switch to Interactive Switching View</span>
              <span className="material-symbols-outlined text-[16px]">arrow_forward</span>
            </a>
          </div>
        </div>

        {/* 3 Insight Bento Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-space-md">
          {/* Card 1: Shared Armor Strategy */}
          <div className="bg-surface-container p-space-md rounded-lg flex flex-col justify-between space-y-space-sm border border-surface-container-high/30">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-caps text-label-caps text-tertiary uppercase flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">verified</span> Shared Armor
                  Strategy (7 Slots)
                </span>
                <span className="font-data-sm text-data-sm text-tertiary bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-tertiary/20">
                  +2 Inven
                </span>
              </div>
              <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                Retaining <span className="text-on-surface font-semibold">Fighter Torso &amp; Obsidian Platelegs</span>{' '}
                into Ranged stance incurs only a nominal{' '}
                <span className="text-primary font-semibold">-11 Ranged Attack</span> penalty. This preserves{' '}
                <span className="text-tertiary font-semibold">2 inventory slots</span> for Saradomin brews while
                maintaining a critical +142 Melee Defense baseline during spawn walks.
              </p>
            </div>
            <div className="flex items-center gap-space-xs font-data-sm text-data-sm text-on-surface-variant pt-space-xs bg-surface-container-lowest px-space-sm py-1 rounded border border-surface-container-high/20">
              <span className="material-symbols-outlined text-[15px] text-tertiary">check_circle</span>
              <span>Zero tick loss on style change</span>
            </div>
          </div>

          {/* Card 2: Swap Allocation Yield */}
          <div className="bg-surface-container p-space-md rounded-lg flex flex-col justify-between space-y-space-sm border border-surface-container-high/30">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-caps text-label-caps text-primary uppercase flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">tune</span> Swap Allocation Yield
                  (4 Slots)
                </span>
                <span className="font-data-sm text-data-sm text-primary bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-primary/20">
                  89.4% Eff
                </span>
              </div>
              <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                The active 4-swap configuration—
                <span className="text-on-surface font-semibold">
                  Toxic Blowpipe, Shield Offhand drop, Ava's Accumulator, and Necklace of Anguish
                </span>
                —captures{' '}
                <span className="text-primary font-semibold">89.4% of maximum theoretical hybrid DPS</span>{' '}
                against Vorkath's draconic threshold, maximizing DPS without inventory clutter.
              </p>
            </div>
            <div className="flex items-center gap-space-xs font-data-sm text-data-sm text-on-surface-variant pt-space-xs bg-surface-container-lowest px-space-sm py-1 rounded border border-surface-container-high/20">
              <span className="material-symbols-outlined text-[15px] text-primary">flash_on</span>
              <span>Optimal swap-to-damage ratio</span>
            </div>
          </div>

          {/* Card 3: Rejected 6-Way Swap */}
          <div className="bg-surface-container p-space-md rounded-lg flex flex-col justify-between space-y-space-sm border border-surface-container-high/30">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-label-caps text-label-caps text-error uppercase flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">block</span> Rejected 6-Way Swap
                  Candidate
                </span>
                <span className="font-data-sm text-data-sm text-error bg-surface-container-lowest px-1.5 py-0.5 rounded font-bold border border-error/20">
                  +0.38 DPS
                </span>
              </div>
              <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
                Adding <span className="text-on-surface font-semibold">Blessed D'hide Body &amp; Chaps</span> was
                evaluated: while it grants +0.38 Ranged DPS, it immediately violates the{' '}
                <span className="text-primary font-semibold">4-swap inventory constraint</span>, consuming 2
                additional food slots and reducing trip longevity by 1.4 kills per instance.
              </p>
            </div>
            <div className="flex items-center gap-space-xs font-data-sm text-data-sm text-error pt-space-xs bg-surface-container-lowest px-space-sm py-1 rounded border border-error/20">
              <span className="material-symbols-outlined text-[15px] text-error">trending_down</span>
              <span>Rejected: -18.2% Total Trip Survivability</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
