import React, { useState } from 'react';
import { ScreenType, TransitionType } from '../types';

interface MultiInteractiveSwitchingProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: (prompt?: string) => void;
}

export const MultiInteractiveSwitching: React.FC<MultiInteractiveSwitchingProps> = ({
  onNavigate,
}) => {
  const [currentStance, setCurrentStance] = useState<'melee' | 'ranged'>('melee');
  const [copiedTags, setCopiedTags] = useState(false);

  const handleViewSideBySide = () => {
    // Spec: Element (xpath: //button[@id='view-side-by-side']) → Multi-Style Optimizer — Side-by-Side Comparison (none transition)
    onNavigate('multi-side', 'none');
  };

  const handleExportRuneLite = () => {
    const text = 'vorkath_melee_ranged_4swap,4151,6570,6585,11283,12926,22109,19553,21905';
    navigator.clipboard?.writeText(text);
    setCopiedTags(true);
    setTimeout(() => setCopiedTags(false), 2000);
  };

  const isMelee = currentStance === 'melee';

  return (
    <div className="flex flex-col w-full p-margin gap-space-lg select-none">
      {/* Context Sub-Header Banner (HUD Matrix) */}
      <div className="w-full bg-surface-container-low rounded-lg p-space-md flex flex-wrap items-center justify-between gap-space-md shadow-md border border-surface-container-high/40">
        <div className="flex items-center gap-space-lg flex-wrap">
          <div className="flex items-center gap-space-sm bg-surface-container px-space-md py-space-xs rounded border border-surface-container-high/30">
            <span className="material-symbols-outlined text-primary text-[18px]">file_download_done</span>
            <div className="flex flex-col">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                Target Entity
              </span>
              <span className="font-headline-sm text-headline-sm text-on-surface leading-tight">
                Vorkath <span className="font-data-sm text-data-sm text-primary">[Lvl 732 · Draconic]</span>
              </span>
            </div>
          </div>

          <div className="flex items-center gap-space-xs bg-surface-container-lowest p-space-xs rounded border border-surface-container-high/40">
            {/* EXACT MATCH FOR XPATH: //button[@id='view-side-by-side'] */}
            <button
              className="px-space-md py-space-xs rounded font-label-caps text-label-caps text-on-surface-variant hover:text-on-surface transition-all flex items-center gap-space-xs cursor-pointer"
              id="view-side-by-side"
              onClick={handleViewSideBySide}
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">view_column</span>
              <span>Side-by-Side View</span>
            </button>

            <button
              className="px-space-md py-space-xs rounded font-label-caps text-label-caps bg-surface-container text-primary shadow-sm flex items-center gap-space-xs border border-primary/20"
              id="view-interactive"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">animation</span>
              <span>Interactive Switching (Active)</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-space-md">
          <div className="flex items-center gap-space-sm bg-surface-container px-space-md py-space-xs rounded border border-surface-container-high/30">
            <span className="material-symbols-outlined text-tertiary text-[18px]">inventory_2</span>
            <div className="flex flex-col">
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                Swap Constraint Budget
              </span>
              <div className="flex items-center gap-space-xs">
                <span className="font-data-md text-data-md text-tertiary">4 / 4 Swaps Utilized</span>
                <span className="font-label-caps text-label-caps text-on-surface-variant">
                  (100% Calibrated)
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-space-xs">
            <button
              onClick={handleExportRuneLite}
              className="px-space-md py-space-xs bg-primary hover:bg-primary-container text-on-primary rounded font-title-md text-title-md flex items-center gap-space-xs transition-colors shadow-sm cursor-pointer"
              id="btn-export-runelite"
              type="button"
            >
              <span className="material-symbols-outlined text-[16px]">
                {copiedTags ? 'check' : 'file_download'}
              </span>
              <span>{copiedTags ? 'Copied to Clipboard!' : 'Export RuneLite Tags'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Workspace: 12-Column Grid Layout */}
      <div className="w-full grid grid-cols-12 gap-space-lg">
        {/* Left/Center Column (8 Cols): Interactive Paperdoll Grid & Stance Controller */}
        <div className="col-span-12 xl:col-span-8 flex flex-col gap-space-md">
          {/* Stance Switcher Matrix */}
          <div className="bg-surface-container-low rounded-lg p-space-md flex flex-col gap-space-sm shadow-md border border-surface-container-high/30">
            <div className="flex items-center justify-between flex-wrap gap-space-sm">
              <div className="flex items-center gap-space-xs bg-surface-container-lowest p-space-xs rounded-lg w-full sm:w-auto border border-surface-container-high/40">
                <button
                  type="button"
                  onClick={() => setCurrentStance('melee')}
                  className={`flex-1 sm:flex-initial px-space-lg py-space-sm rounded font-title-md text-title-md transition-all flex items-center justify-center gap-space-sm cursor-pointer ${
                    isMelee
                      ? 'bg-surface-container text-primary shadow-[0_0_12px_rgba(240,191,92,0.2)] font-bold border border-primary/30'
                      : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                  }`}
                  id="tab-melee"
                >
                  <span className="material-symbols-outlined text-[18px]">swords</span>
                  <span>Melee Stance (Active)</span>
                  {isMelee && <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span>}
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStance('ranged')}
                  className={`flex-1 sm:flex-initial px-space-lg py-space-sm rounded font-title-md text-title-md transition-all flex items-center justify-center gap-space-sm cursor-pointer ${
                    !isMelee
                      ? 'bg-surface-container text-secondary shadow-[0_0_12px_rgba(123,208,255,0.2)] font-bold border border-secondary/30'
                      : 'text-on-surface-variant hover:bg-surface-container hover:text-on-surface'
                  }`}
                  id="tab-ranged"
                >
                  <span className="material-symbols-outlined text-[18px]">adjust</span>
                  <span>Ranged Stance {!isMelee ? '(Active)' : '(Preview)'}</span>
                  <span className="px-space-xs py-[2px] bg-secondary-fixed/20 text-secondary font-data-sm text-data-sm rounded border border-secondary/20">
                    4 Swaps
                  </span>
                </button>
              </div>

              <div className="flex items-center gap-space-xs px-space-md py-space-xs rounded bg-surface-container text-on-surface-variant border border-surface-container-high/30">
                <span className="material-symbols-outlined text-secondary text-[16px]">info</span>
                <span className="font-body-sm text-body-sm" id="stance-instruction">
                  {isMelee
                    ? 'Active: Melee DPS. Click Ranged to simulate real-time gear swap animation.'
                    : 'Active: Ranged DPS. Equipped Blowpipe and Anguish. Click Melee to swap back.'}
                </span>
              </div>
            </div>
          </div>

          {/* Main Equipment Paperdoll Arena & Spec Sheet */}
          <div className="bg-surface-container-low rounded-lg p-space-lg flex flex-col lg:flex-row gap-space-xl items-center justify-between shadow-md relative overflow-hidden border border-surface-container-high/30">
            {/* Visual Backdrop Grid Artifact */}
            <div className="absolute -right-16 -bottom-16 w-80 h-80 bg-primary/5 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -left-16 -top-16 w-72 h-72 bg-secondary/5 rounded-full blur-3xl pointer-events-none"></div>

            {/* OSRS 11-Slot Paperdoll (Precision HUD Arrangement) */}
            <div className="w-full max-w-[360px] flex flex-col items-center gap-space-sm py-space-sm shrink-0">
              <div className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-widest mb-space-xs">
                Equipped Geometry <span className="text-primary font-data-sm">// PAPERDOLL</span>
              </div>

              {/* Row 1: Head Slot */}
              <div className="flex justify-center w-full">
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Slayer Helmet (i)"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">hardware</span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    Slayer(i)
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>
              </div>

              {/* Row 2: Cape, Neck, Ammo */}
              <div className="flex justify-between items-center w-full px-space-sm">
                {/* Cape (SWAP 1) */}
                <div
                  className={`group relative w-16 h-16 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all shadow-md bg-surface-container-high border ${
                    isMelee ? 'border-primary/40' : 'border-secondary/40'
                  }`}
                  id="slot-cape"
                >
                  <span
                    className={`material-symbols-outlined text-[24px] ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                  >
                    {isMelee ? 'person_apron' : 'backpack'}
                  </span>
                  <span
                    className={`font-data-sm text-data-sm font-bold mt-1 truncate max-w-[56px] text-center ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                    id="label-cape"
                    title={isMelee ? 'Fire Cape' : "Ava's Accumulator"}
                  >
                    {isMelee ? 'Fire Cape' : "Ava's Acc"}
                  </span>
                  <span
                    className={`absolute -top-2.5 -left-1 px-space-xs py-[1px] font-label-caps text-[9px] rounded font-bold shadow-sm ${
                      isMelee ? 'bg-primary text-on-primary' : 'bg-secondary text-on-secondary'
                    }`}
                  >
                    ⚡ Swap 1
                  </span>
                </div>

                {/* Neck (SWAP 2) */}
                <div
                  className={`group relative w-16 h-16 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all shadow-md bg-surface-container-high border ${
                    isMelee ? 'border-primary/40' : 'border-secondary/40'
                  }`}
                  id="slot-neck"
                >
                  <span
                    className={`material-symbols-outlined text-[24px] ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                  >
                    {isMelee ? 'all_inclusive' : 'lens'}
                  </span>
                  <span
                    className={`font-data-sm text-data-sm font-bold mt-1 truncate max-w-[56px] text-center ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                    id="label-neck"
                    title={isMelee ? 'Amulet of Fury' : 'Necklace of Anguish'}
                  >
                    {isMelee ? 'Fury' : 'Anguish'}
                  </span>
                  <span
                    className={`absolute -top-2.5 -right-1 px-space-xs py-[1px] font-label-caps text-[9px] rounded font-bold shadow-sm ${
                      isMelee ? 'bg-primary text-on-primary' : 'bg-secondary text-on-secondary'
                    }`}
                  >
                    ⚡ Swap 2
                  </span>
                </div>

                {/* Ammo (Shared) */}
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Rada's Blessing 2"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">
                    military_tech
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    Rada 2
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>
              </div>

              {/* Row 3: Weapon, Body, Shield */}
              <div className="flex justify-between items-center w-full px-space-sm">
                {/* Weapon (SWAP 3) */}
                <div
                  className={`group relative w-16 h-16 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all shadow-md bg-surface-container-high border ${
                    isMelee ? 'border-primary/40' : 'border-secondary/40'
                  }`}
                  id="slot-weapon"
                >
                  <span
                    className={`material-symbols-outlined text-[24px] ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                  >
                    {isMelee ? 'colorize' : 'air'}
                  </span>
                  <span
                    className={`font-data-sm text-data-sm font-bold mt-1 truncate max-w-[56px] text-center ${
                      isMelee ? 'text-primary' : 'text-secondary'
                    }`}
                    id="label-weapon"
                    title={isMelee ? 'Abyssal Whip' : 'Toxic Blowpipe'}
                  >
                    {isMelee ? 'Whip' : 'Blowpipe'}
                  </span>
                  <span
                    className={`absolute -bottom-2.5 -left-1 px-space-xs py-[1px] font-label-caps text-[9px] rounded font-bold shadow-sm ${
                      isMelee ? 'bg-primary text-on-primary' : 'bg-secondary text-on-secondary'
                    }`}
                  >
                    ⚡ Swap 3
                  </span>
                </div>

                {/* Body (Shared) */}
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Fighter Torso"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">shield</span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    Torso
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>

                {/* Shield (SWAP 4) */}
                <div
                  className={`group relative w-16 h-16 rounded-lg flex flex-col items-center justify-center cursor-pointer transition-all shadow-md ${
                    isMelee
                      ? 'bg-surface-container-high border border-primary/40'
                      : 'bg-surface-container-lowest opacity-60 border border-surface-container-high/20'
                  }`}
                  id="slot-shield"
                >
                  <span
                    className={`material-symbols-outlined text-[24px] ${
                      isMelee ? 'text-primary' : 'text-on-surface-variant'
                    }`}
                  >
                    {isMelee ? 'security' : 'do_not_disturb_on'}
                  </span>
                  <span
                    className={`font-data-sm text-data-sm font-bold mt-1 truncate max-w-[56px] text-center ${
                      isMelee ? 'text-primary' : 'text-on-surface-variant'
                    }`}
                    id="label-shield"
                    title={isMelee ? 'Anti-Dragon Shield' : 'Empty (Two-Handed)'}
                  >
                    {isMelee ? 'Dragon Shld' : '(2-Handed)'}
                  </span>
                  <span
                    className={`absolute -bottom-2.5 -right-1 px-space-xs py-[1px] font-label-caps text-[9px] rounded font-bold shadow-sm ${
                      isMelee ? 'bg-primary text-on-primary' : 'bg-surface-container text-on-surface-variant'
                    }`}
                  >
                    ⚡ Swap 4
                  </span>
                </div>
              </div>

              {/* Row 4: Legs (Shared) */}
              <div className="flex justify-center w-full">
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Obsidian Platelegs"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">
                    roller_shades
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    Obsidian
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>
              </div>

              {/* Row 5: Gloves, Boots, Ring */}
              <div className="flex justify-between items-center w-full px-space-sm">
                {/* Gloves (Shared) */}
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Barrows Gloves"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">
                    front_hand
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    Barrows
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>

                {/* Boots (Shared) */}
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Dragon Boots"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">
                    snowshoeing
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    D Boots
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>

                {/* Ring (Shared) */}
                <div
                  className="group relative w-16 h-16 bg-surface-container rounded-lg flex flex-col items-center justify-center cursor-pointer hover:bg-surface-container-high transition-colors shadow-sm border border-surface-container-high/30"
                  title="Berserker Ring (i)"
                >
                  <span className="material-symbols-outlined text-on-surface-variant text-[24px]">lens</span>
                  <span className="font-data-sm text-data-sm text-on-surface mt-1 truncate max-w-[56px] text-center">
                    B Ring (i)
                  </span>
                  <span className="absolute -top-2 -right-2 px-space-xs py-[1px] bg-surface-container-highest text-tertiary font-label-caps text-[9px] rounded uppercase shadow-sm border border-tertiary/20">
                    Shared
                  </span>
                </div>
              </div>
            </div>

            {/* Interactive Transition & Stat Projection Column */}
            <div className="w-full flex-1 flex flex-col gap-space-md">
              <div className="bg-surface-container rounded-lg p-space-md flex flex-col gap-space-sm shadow-sm border border-surface-container-high/30">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                    Current Stance Telemetry
                  </span>
                  <span
                    className={`px-space-xs py-[2px] rounded font-label-caps text-label-caps ${
                      isMelee ? 'bg-primary text-on-primary' : 'bg-secondary text-on-secondary'
                    }`}
                    id="stance-badge"
                  >
                    {isMelee ? 'Melee Mode Active' : 'Ranged Mode Active'}
                  </span>
                </div>

                {/* Primary Metric Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-space-sm mt-space-xs">
                  <div className="bg-surface-container-low p-space-sm rounded flex flex-col border border-surface-container-high/30">
                    <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                      Effective DPS
                    </span>
                    <span
                      className={`font-data-lg text-data-lg mt-1 ${
                        isMelee ? 'text-primary' : 'text-secondary'
                      }`}
                      id="stat-dps"
                    >
                      {isMelee ? '6.84 eDPS' : '7.12 eDPS'}
                    </span>
                    <span className="font-data-sm text-data-sm text-tertiary mt-0.5">
                      {isMelee ? 'Rank #1 in setup' : 'Peak Toxic speed'}
                    </span>
                  </div>
                  <div className="bg-surface-container-low p-space-sm rounded flex flex-col border border-surface-container-high/30">
                    <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                      Max Hit
                    </span>
                    <span className="font-data-lg text-data-lg text-on-surface mt-1" id="stat-maxhit">
                      {isMelee ? '42 DMG' : '28 DMG'}
                    </span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant mt-0.5">
                      {isMelee ? 'Slash: +94 Str' : 'Dart: Dragonbane'}
                    </span>
                  </div>
                  <div className="bg-surface-container-low p-space-sm rounded flex flex-col border border-surface-container-high/30">
                    <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                      Hit Accuracy
                    </span>
                    <span className="font-data-lg text-data-lg text-secondary mt-1" id="stat-acc">
                      {isMelee ? '64.2%' : '71.8%'}
                    </span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant mt-0.5">
                      {isMelee ? 'vs 26 Slash Def' : 'vs 26 Range Def'}
                    </span>
                  </div>
                  <div className="bg-surface-container-low p-space-sm rounded flex flex-col border border-surface-container-high/30">
                    <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                      Attack Cycle
                    </span>
                    <span className="font-data-lg text-data-lg text-on-surface mt-1" id="stat-speed">
                      {isMelee ? '4 Ticks' : '2 Ticks'}
                    </span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant mt-0.5">
                      {isMelee ? '2.4s cadence' : '1.2s rapid cycle'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Stance Transition Delta Banner */}
              <div
                className="bg-surface-container p-space-md rounded-lg flex flex-col gap-space-xs shadow-sm border border-surface-container-high/30"
                id="transition-delta-card"
              >
                <div className="flex items-center justify-between">
                  <span className="font-title-md text-title-md text-on-surface flex items-center gap-space-xs">
                    <span className="material-symbols-outlined text-secondary text-[18px]">transform</span>
                    <span>
                      {isMelee
                        ? 'Swap Projection (Melee ➔ Ranged)'
                        : 'Swap Projection (Ranged ➔ Melee)'}
                    </span>
                  </span>
                  <span className="font-data-md text-data-md text-tertiary font-bold">
                    {isMelee ? '+0.28 net eDPS' : '-0.28 net eDPS (Shield Back)'}
                  </span>
                </div>
                <p className="font-body-md text-body-md text-on-surface-variant" id="transition-summary">
                  {isMelee ? (
                    <>
                      Switching to Ranged will yield{' '}
                      <span className="text-on-surface font-semibold">7.12 DPS</span> (+4.1% DPS boost) at the
                      cost of <span className="text-primary font-semibold">4 inventory slots</span> during Acid
                      Phase / Woox Walk.
                    </>
                  ) : (
                    <>
                      Active Ranged setup delivers maximum rapid-fire rate on Woox walk. Inventory holds{' '}
                      <span className="text-on-surface font-semibold">
                        Whip, Fire Cape, Fury &amp; Dragon Shield
                      </span>
                      .
                    </>
                  )}
                </p>
                <div className="w-full bg-surface-container-lowest h-2 rounded overflow-hidden mt-space-xs">
                  <div
                    className="bg-primary h-full transition-all duration-300"
                    id="dps-progress-bar"
                    style={{ width: isMelee ? '78%' : '89%' }}
                  ></div>
                </div>
              </div>

              {/* Detailed Swap Exchange Mapping */}
              <div className="bg-surface-container rounded-lg p-space-md flex flex-col gap-space-sm shadow-sm border border-surface-container-high/30">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase tracking-wider">
                  Dynamic Transition Mapping
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-space-xs">
                  <div className="flex items-center justify-between bg-surface-container-low px-space-md py-space-xs rounded border border-surface-container-high/20">
                    <div className="flex items-center gap-space-xs">
                      <span className="material-symbols-outlined text-primary text-[14px]">swap_horiz</span>
                      <span className="font-label-caps text-label-caps text-on-surface-variant">Cape:</span>
                    </div>
                    <span className="font-data-sm text-data-sm text-on-surface" id="map-cape">
                      {isMelee ? (
                        <>
                          Fire Cape <span className="text-secondary">➔</span> Ava's Accum.
                        </>
                      ) : (
                        <>
                          Ava's Accum. <span className="text-primary">➔</span> Fire Cape
                        </>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-surface-container-low px-space-md py-space-xs rounded border border-surface-container-high/20">
                    <div className="flex items-center gap-space-xs">
                      <span className="material-symbols-outlined text-primary text-[14px]">swap_horiz</span>
                      <span className="font-label-caps text-label-caps text-on-surface-variant">Neck:</span>
                    </div>
                    <span className="font-data-sm text-data-sm text-on-surface" id="map-neck">
                      {isMelee ? (
                        <>
                          Fury <span className="text-secondary">➔</span> Anguish
                        </>
                      ) : (
                        <>
                          Anguish <span className="text-primary">➔</span> Fury
                        </>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-surface-container-low px-space-md py-space-xs rounded border border-surface-container-high/20">
                    <div className="flex items-center gap-space-xs">
                      <span className="material-symbols-outlined text-primary text-[14px]">swap_horiz</span>
                      <span className="font-label-caps text-label-caps text-on-surface-variant">Mainhand:</span>
                    </div>
                    <span className="font-data-sm text-data-sm text-on-surface" id="map-weapon">
                      {isMelee ? (
                        <>
                          Abyssal Whip <span className="text-secondary">➔</span> Blowpipe
                        </>
                      ) : (
                        <>
                          Blowpipe <span className="text-primary">➔</span> Abyssal Whip
                        </>
                      )}
                    </span>
                  </div>
                  <div className="flex items-center justify-between bg-surface-container-low px-space-md py-space-xs rounded border border-surface-container-high/20">
                    <div className="flex items-center gap-space-xs">
                      <span className="material-symbols-outlined text-primary text-[14px]">swap_horiz</span>
                      <span className="font-label-caps text-label-caps text-on-surface-variant">Offhand:</span>
                    </div>
                    <span className="font-data-sm text-data-sm text-on-surface" id="map-shield">
                      {isMelee ? (
                        <>
                          Anti-Dragon <span className="text-secondary">➔</span> (2H Inhand)
                        </>
                      ) : (
                        <>
                          (2H Inhand) <span className="text-primary">➔</span> Anti-Dragon
                        </>
                      )}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (4 Cols): Visual 28-Slot Inventory Footprint & Impact Ledger */}
        <div className="col-span-12 xl:col-span-4 flex flex-col gap-space-md">
          {/* 28-Slot Inventory Backpack Visualization */}
          <div className="bg-surface-container-low rounded-lg p-space-md flex flex-col gap-space-sm shadow-md border border-surface-container-high/30">
            <div className="flex items-center justify-between flex-wrap gap-space-xs">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">backpack</span>
                <span className="font-headline-sm text-headline-sm text-on-surface">Inventory Footprint</span>
              </div>
              <span className="px-space-xs py-[2px] rounded font-label-caps text-label-caps bg-tertiary-container text-on-tertiary font-bold border border-tertiary/20">
                24 / 28 Slots Free
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Strict 4-item allocation reserve. Preserves max consumable density for extended kill trips.
            </p>

            {/* Visual 4x7 Inventory Grid (OSRS Standard Layout) */}
            <div className="bg-surface-container-lowest p-space-md rounded-lg flex flex-col items-center border border-surface-container-high/30">
              <div className="grid grid-cols-4 gap-1.5 w-full max-w-[280px]">
                {/* Row 1: The 4 Gear Swaps (Explicitly highlighted & populated based on current stance) */}
                <div
                  className="group relative aspect-square bg-surface-container-high rounded flex flex-col items-center justify-center shadow-sm border border-primary/30"
                  id="inv-slot-0"
                >
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    {isMelee ? 'colorize' : 'sports_martial_arts'}
                  </span>
                  <span
                    className="font-data-sm text-[10px] text-primary truncate max-w-[50px] text-center"
                    id="inv-text-0"
                  >
                    {isMelee ? 'Blowpipe' : 'Whip'}
                  </span>
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-primary rounded-full"></span>
                </div>
                <div
                  className="group relative aspect-square bg-surface-container-high rounded flex flex-col items-center justify-center shadow-sm border border-primary/30"
                  id="inv-slot-1"
                >
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    {isMelee ? 'person_apron' : 'shield'}
                  </span>
                  <span
                    className="font-data-sm text-[10px] text-primary truncate max-w-[50px] text-center"
                    id="inv-text-1"
                  >
                    {isMelee ? "Ava's" : 'Fire Cape'}
                  </span>
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-primary rounded-full"></span>
                </div>
                <div
                  className="group relative aspect-square bg-surface-container-high rounded flex flex-col items-center justify-center shadow-sm border border-primary/30"
                  id="inv-slot-2"
                >
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    {isMelee ? 'all_inclusive' : 'circle'}
                  </span>
                  <span
                    className="font-data-sm text-[10px] text-primary truncate max-w-[50px] text-center"
                    id="inv-text-2"
                  >
                    {isMelee ? 'Anguish' : 'Fury'}
                  </span>
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-primary rounded-full"></span>
                </div>
                <div
                  className="group relative aspect-square bg-surface-container-high rounded flex flex-col items-center justify-center shadow-sm border border-primary/30"
                  id="inv-slot-3"
                >
                  <span className="material-symbols-outlined text-primary text-[18px]">
                    {isMelee ? 'radio_button_checked' : 'security'}
                  </span>
                  <span
                    className="font-data-sm text-[10px] text-primary truncate max-w-[50px] text-center"
                    id="inv-text-3"
                  >
                    {isMelee ? 'R Bolts(e)' : 'Dragon Shld'}
                  </span>
                  <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-primary rounded-full"></span>
                </div>

                {/* Row 2: Potions / Boosts (Available Slots) */}
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-tertiary text-[16px]">science</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">S-Combat</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary text-[16px]">science</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Range Pot</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary-fixed text-[16px]">science</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Ext Anti</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-tertiary text-[16px]">science</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Anti-Ven+</span>
                </div>

                {/* Row 3: Restores / Prayers */}
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary-container text-[16px]">
                    water_drop
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Prayer(4)</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary-container text-[16px]">
                    water_drop
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Prayer(4)</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary-container text-[16px]">
                    water_drop
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Prayer(4)</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary-container text-[16px]">
                    water_drop
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Prayer(4)</span>
                </div>

                {/* Rows 4 to 7: High-Healing Food */}
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>

                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Shark</span>
                </div>

                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Karambwan</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Karambwan</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Karambwan</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary-fixed-dim text-[16px]">
                    set_meal
                  </span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Karambwan</span>
                </div>

                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-error text-[16px]">local_hospital</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Emergency</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-on-surface text-[16px]">cottage</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">House Tab</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-primary text-[16px]">flare</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Rune Pouch</span>
                </div>
                <div className="aspect-square bg-surface-container rounded flex flex-col items-center justify-center hover:bg-surface-container-high transition-colors">
                  <span className="material-symbols-outlined text-secondary text-[16px]">token</span>
                  <span className="font-data-sm text-[9px] text-on-surface-variant">Staff of D</span>
                </div>
              </div>
            </div>
          </div>

          {/* Swap Impact Ledger (Ranked by DPS Contribution) */}
          <div className="bg-surface-container-low rounded-lg p-space-md flex flex-col gap-space-sm shadow-md border border-surface-container-high/30">
            <div className="flex items-center justify-between">
              <span className="font-headline-sm text-headline-sm text-on-surface">Swap Impact Ledger</span>
              <span className="font-label-caps text-label-caps text-primary uppercase">Ranked ROI</span>
            </div>
            <div className="flex flex-col gap-space-xs">
              {/* Item #1 */}
              <div className="p-space-sm bg-surface-container rounded flex items-center justify-between border border-surface-container-high/30">
                <div className="flex items-center gap-space-sm">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center font-data-sm text-data-sm font-bold">
                    1
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface">Mainhand Weapon</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">
                      Whip ⇄ Toxic Blowpipe
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-data-md text-data-md text-tertiary font-bold">+1.42 eDPS</span>
                  <span className="font-label-caps text-[10px] text-primary uppercase">Vital Impact</span>
                </div>
              </div>
              {/* Item #2 */}
              <div className="p-space-sm bg-surface-container rounded flex items-center justify-between border border-surface-container-high/30">
                <div className="flex items-center gap-space-sm">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center font-data-sm text-data-sm font-bold">
                    2
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface">Amulet / Neck</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">Fury ⇄ Anguish</span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-data-md text-data-md text-tertiary font-bold">+0.48 eDPS</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">+5 Ranged Str</span>
                </div>
              </div>
              {/* Item #3 */}
              <div className="p-space-sm bg-surface-container rounded flex items-center justify-between border border-surface-container-high/30">
                <div className="flex items-center gap-space-sm">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center font-data-sm text-data-sm font-bold">
                    3
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface">Back / Cape</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">
                      Fire Cape ⇄ Ava's
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-data-md text-data-md text-tertiary font-bold">+0.34 eDPS</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">72% ammo save</span>
                </div>
              </div>
              {/* Item #4 */}
              <div className="p-space-sm bg-surface-container rounded flex items-center justify-between border border-surface-container-high/30">
                <div className="flex items-center gap-space-sm">
                  <span className="w-5 h-5 rounded-full bg-primary/20 text-primary flex items-center justify-center font-data-sm text-data-sm font-bold">
                    4
                  </span>
                  <div className="flex flex-col">
                    <span className="font-title-md text-title-md text-on-surface">Shield / Offhand</span>
                    <span className="font-data-sm text-data-sm text-on-surface-variant">
                      Anti-Dragon ⇄ 2H Slot
                    </span>
                  </div>
                </div>
                <div className="flex flex-col items-end">
                  <span className="font-data-md text-data-md text-secondary font-bold">2H Speed</span>
                  <span className="font-data-sm text-data-sm text-on-surface-variant">Blowpipe unlock</span>
                </div>
              </div>
            </div>
          </div>

          {/* Algorithmic Decision Callout Card */}
          <div className="bg-surface-container-low rounded-lg p-space-md flex flex-col gap-space-xs shadow-md border border-surface-container-high/30">
            <div className="flex items-center gap-space-xs text-primary">
              <span className="material-symbols-outlined text-[18px]">psychology</span>
              <span className="font-label-caps text-label-caps uppercase tracking-wider">
                Algorithmic Decision Matrix
              </span>
            </div>
            <p className="font-body-md text-body-md text-on-surface-variant leading-relaxed">
              <span className="text-on-surface font-semibold">Why 4 swaps instead of 6?</span> Preserving Torso
              &amp; Obsidian legs saves <span className="text-primary font-semibold">2 inventory slots</span> for
              32 extra HP in food while sacrificing only{' '}
              <span className="text-secondary font-semibold">2.1% accuracy</span> on Vorkath. Net survivability
              increases by 18.4%.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
