import React, { useState } from 'react';
import { ScreenType, TransitionType } from '../types';

interface SinglePostOptimizationProps {
  onNavigate: (screen: ScreenType, transition?: TransitionType) => void;
  onOpenAdvisor?: (prompt?: string) => void;
}

export const SinglePostOptimization: React.FC<SinglePostOptimizationProps> = ({
  onNavigate,
  onOpenAdvisor,
}) => {
  const [copiedBuyList, setCopiedBuyList] = useState(false);
  const [whatIfOpen, setWhatIfOpen] = useState(false);
  const [copyCheck, setCopyCheck] = useState(true);
  const [lockMultiStyle, setLockMultiStyle] = useState(false);

  const handleExportBuyList = () => {
    const text = 'buy 1 Abyssal whip 1650000\nbuy 1 Obsidian platelegs 980000\nbuy 1 Dragon boots 185000';
    navigator.clipboard?.writeText(text);
    setCopiedBuyList(true);
    setTimeout(() => setCopiedBuyList(false), 2000);
  };

  return (
    <div className="flex flex-col w-full p-margin gap-space-lg select-none">
      {/* Top Sub-Header / Telemetry Status Bar */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-space-md p-space-md bg-surface-container-low rounded-xl shadow-md border border-surface-container-high/40">
        <div className="flex items-center gap-space-md flex-wrap">
          <div className="flex items-center gap-space-xs px-space-sm py-space-xs bg-tertiary-container/15 text-tertiary rounded border border-tertiary/20">
            <span className="material-symbols-outlined text-[16px] text-tertiary">check_circle</span>
            <span className="font-label-caps text-label-caps uppercase tracking-wider font-bold">
              MODE: SINGLE-STYLE
            </span>
          </div>
          <div className="h-4 w-[1px] bg-outline-variant hidden sm:block"></div>
          <div className="flex items-center gap-space-xs font-data-sm text-data-sm text-on-surface">
            <span className="text-primary font-bold">OPTIMAL CONVERGENCE FOUND</span>
            <span className="text-on-surface-variant font-data-sm text-data-sm">
              (Computed in 14.2ms · 6,240 Permutations Evaluated)
            </span>
          </div>
          <div className="hidden xl:flex items-center gap-space-xs font-data-sm text-data-sm text-on-surface-variant bg-surface-container px-space-sm py-space-xs rounded border border-surface-container-high/30">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary"></span>
            <span>Sim Tier: High-Precision (0.01% CI)</span>
          </div>
        </div>

        <div className="flex items-center gap-space-sm">
          {/* Re-run Optimizer button (push_back transition) */}
          <button
            onClick={() => onNavigate('single-pre', 'push_back')}
            className="flex items-center gap-space-xs px-space-md py-space-xs bg-surface-container hover:bg-surface-container-high text-on-surface rounded font-title-md text-title-md transition-colors shadow-sm cursor-pointer border border-surface-container-high/40"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px] text-on-surface-variant">refresh</span>
            <span>Re-run Optimizer</span>
          </button>

          <button
            onClick={handleExportBuyList}
            className="flex items-center gap-space-xs px-space-md py-space-xs bg-primary hover:bg-primary-container text-on-primary font-title-md text-title-md font-bold rounded transition-colors shadow-md cursor-pointer"
            type="button"
          >
            <span className="material-symbols-outlined text-[16px]">
              {copiedBuyList ? 'check' : 'shopping_cart_checkout'}
            </span>
            <span>{copiedBuyList ? 'Copied to Clipboard!' : 'Export GE Buy-List (3 items)'}</span>
          </button>
        </div>
      </div>

      {/* Three-Column Primary Workspace (12-Column Responsive Bento) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-gutter items-start">
        {/* LEFT COLUMN: Configuration & Financial Acquisition (3 Cols) */}
        <div className="lg:col-span-3 flex flex-col gap-space-md">
          {/* Encounter Context Card */}
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">adjust</span>
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Active Target &amp; Combat
                </span>
              </div>
              <button
                className="w-6 h-6 rounded flex items-center justify-center text-on-surface-variant hover:text-primary hover:bg-surface-container transition-colors"
                title="Change target parameters"
                type="button"
              >
                <span className="material-symbols-outlined text-[16px]">edit</span>
              </button>
            </div>
            <div className="flex items-center gap-space-md p-space-sm bg-surface-container rounded-lg border border-surface-container-high/30">
              <div className="w-11 h-11 rounded bg-surface-container-highest flex items-center justify-center shrink-0">
                <span className="material-symbols-outlined text-[24px] text-secondary">pest_control</span>
              </div>
              <div className="flex flex-col min-w-0">
                <div className="flex items-center gap-space-xs">
                  <span className="font-headline-sm text-headline-sm text-on-surface truncate">Vorkath</span>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 rounded bg-surface-container-highest text-secondary">
                    Lvl 732
                  </span>
                </div>
                <span className="font-body-sm text-body-sm text-on-surface-variant truncate">
                  Post-Quest · Undead Dragon
                </span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-space-xs pt-space-xs">
              <div className="p-space-sm bg-surface-container rounded flex flex-col gap-0.5 border border-surface-container-high/30">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Discipline
                </span>
                <span className="font-data-sm text-data-sm text-on-surface font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-error"></span> Melee (Slash)
                </span>
              </div>
              <div className="p-space-sm bg-surface-container rounded flex flex-col gap-0.5 border border-surface-container-high/30">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Objective
                </span>
                <span className="font-data-sm text-data-sm text-primary font-semibold flex items-center gap-1">
                  <span className="material-symbols-outlined text-[13px]">bolt</span> Max DPS
                </span>
              </div>
            </div>
          </div>

          {/* Acquisition & Financial Ledger Card */}
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">
                  account_balance_wallet
                </span>
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Acquisition Summary
                </span>
              </div>
              <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container text-tertiary rounded font-bold border border-tertiary/20">
                Under Cap
              </span>
            </div>
            {/* Budget Gauge Visual */}
            <div className="flex flex-col gap-space-xs">
              <div className="flex justify-between items-baseline font-data-sm text-data-sm">
                <span className="text-on-surface-variant">GE Outlay vs 5,000,000 GP Cap</span>
                <span className="text-primary font-bold">56.3% Utilized</span>
              </div>
              <div className="w-full h-2 rounded-full bg-surface-container-highest overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(240,191,92,0.4)]"
                  style={{ width: '56.3%' }}
                ></div>
              </div>
            </div>
            {/* Ledger Entries */}
            <div className="flex flex-col gap-space-xs divide-y-0">
              <div className="flex justify-between items-center py-space-xs">
                <span className="font-body-sm text-body-sm text-on-surface-variant">Total Gear Value</span>
                <span className="font-data-md text-data-md text-on-surface font-bold">28,450,000 GP</span>
              </div>
              <div className="flex justify-between items-center py-space-xs">
                <div className="flex items-center gap-space-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-tertiary"></span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">Bank/Equipped (8)</span>
                </div>
                <span className="font-data-sm text-data-sm text-tertiary">25,635,000 GP (0 GP)</span>
              </div>
              <div className="flex justify-between items-center py-space-xs">
                <div className="flex items-center gap-space-xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary"></span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">GE Purchase (3)</span>
                </div>
                <span className="font-data-sm text-data-sm text-primary font-bold">2,815,000 GP</span>
              </div>
              <div className="flex justify-between items-center pt-space-xs bg-surface-container p-space-sm rounded border border-surface-container-high/40">
                <span className="font-title-md text-title-md text-on-surface">Budget Remaining</span>
                <span className="font-data-md text-data-md text-tertiary font-bold">+2,185,000 GP</span>
              </div>
            </div>
          </div>

          {/* Collapsible What-If Drawer */}
          <div
            onClick={() => setWhatIfOpen(!whatIfOpen)}
            className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-sm cursor-pointer hover:bg-surface-container transition-colors border border-surface-container-high/30"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-[18px] text-on-surface-variant">tune</span>
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  What-If Scenarios
                </span>
              </div>
              <span className="font-data-sm text-data-sm px-space-xs py-0.5 rounded bg-surface-container-highest text-on-surface-variant">
                {whatIfOpen ? 'Configuring' : 'Inactive'}
              </span>
            </div>
            <p className="font-body-sm text-body-sm text-on-surface-variant">
              Simulate Slayer Task bonuses, Dragon Warhammer specs, or potion variants without resetting state.
            </p>
            <div className="flex items-center gap-space-xs text-primary font-data-sm text-data-sm pt-space-xs">
              <span>Configure 4 Parameters</span>
              <span className={`material-symbols-outlined text-[14px] transition-transform ${whatIfOpen ? 'rotate-90' : ''}`}>
                chevron_right
              </span>
            </div>
          </div>
        </div>

        {/* CENTER COLUMN: Optimized Equipment Results & Paperdoll Grid (6 Cols) */}
        <div className="lg:col-span-6 flex flex-col gap-space-md">
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            {/* Title & Subtitle */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-space-xs">
              <div className="flex flex-col">
                <div className="flex items-center gap-space-xs">
                  <span className="font-headline-sm text-headline-sm text-on-surface font-bold">
                    Optimized Loadout vs Vorkath
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary bg-tertiary/10 px-space-xs py-0.5 rounded border border-tertiary/20">
                    11/11 Validated
                  </span>
                </div>
                <span className="font-body-sm text-body-sm text-on-surface-variant">
                  Click any slot to inspect item details, alternatives, or lock/exclude items.
                </span>
              </div>
              <div className="flex items-center gap-space-xs shrink-0 font-data-sm text-data-sm text-on-surface-variant">
                <span className="inline-block w-2 h-2 rounded-full bg-primary animate-pulse"></span>
                <span>Live Delta Sync</span>
              </div>
            </div>

            {/* 11-Slot Paperdoll Layout Container */}
            <div className="relative bg-surface-container-lowest/80 rounded-xl p-space-md shadow-inner flex flex-col gap-space-sm border border-surface-container-high/30">
              {/* Row 1: Head (Centered) */}
              <div className="flex justify-center">
                <div className="w-full max-w-xs flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-sm min-w-0">
                    <div className="w-9 h-9 rounded bg-surface-container-high flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[20px]">military_tech</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Slayer Helm (i)
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Head Slot</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-tertiary/15 text-tertiary rounded shrink-0">
                    Banked · 0 GP
                  </span>
                </div>
              </div>

              {/* Row 2: Cape, Neck, Ammo (3 Column row) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-xs">
                {/* Cape */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-secondary group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">folded_hands</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Fire Cape
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Cape</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container-highest text-on-surface-variant rounded shrink-0">
                    Equipped
                  </span>
                </div>

                {/* Neck */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-primary group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">circle</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Amulet of Fury
                      </span>
                      <span className="font-body-sm text-body-sm text-secondary truncate">
                        upgraded from Glory
                      </span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-tertiary/15 text-tertiary rounded shrink-0">
                    Banked
                  </span>
                </div>

                {/* Ammo */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-on-surface-variant group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">bolt</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Rada's Blessing 2
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Ammo</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container-highest text-on-surface-variant rounded shrink-0">
                    Equipped
                  </span>
                </div>
              </div>

              {/* Row 3: Weapon, Body, Shield (3 Column row) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-xs">
                {/* Weapon: EXACT MATCH FOR XPATH:
                    //div[contains(@class, 'cursor-pointer')][.//span[contains(text(), 'Abyssal Whip')]]
                */}
                <div
                  onClick={() => onNavigate('single-inspector', 'slide_up')}
                  className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group bg-gradient-to-r from-primary/10 via-surface-container to-surface-container border border-primary/40 shadow-[0_0_8px_rgba(240,191,92,0.2)]"
                >
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-primary/20 text-primary flex items-center justify-center group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">hardware</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-primary font-bold truncate">
                        Abyssal Whip
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Weapon</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-primary text-on-primary font-bold rounded flex items-center gap-0.5 shrink-0">
                    <span className="material-symbols-outlined text-[12px]">shopping_cart</span> 1.65M
                  </span>
                </div>

                {/* Body */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-on-surface-variant group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">shield</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Fighter Torso
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Body</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container-highest text-on-surface-variant rounded shrink-0">
                    Equipped
                  </span>
                </div>

                {/* Shield */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-secondary/20 text-secondary flex items-center justify-center group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">security</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Anti-Dragon Shield
                      </span>
                      <span className="font-body-sm text-body-sm text-secondary truncate">Shield</span>
                    </div>
                  </div>
                  <span
                    className="font-data-sm text-data-sm px-space-xs py-0.5 bg-secondary-fixed/20 text-secondary rounded flex items-center gap-0.5 shrink-0"
                    title="Locked by encounter mechanics"
                  >
                    <span className="material-symbols-outlined text-[12px]">lock</span> Mandatory
                  </span>
                </div>
              </div>

              {/* Row 4: Legs (Centered) */}
              <div className="flex justify-center">
                <div className="w-full max-w-xs flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group bg-gradient-to-r from-primary/10 via-surface-container to-surface-container border border-surface-container-high/30">
                  <div className="flex items-center gap-space-sm min-w-0">
                    <div className="w-8 h-8 rounded bg-primary/20 text-primary flex items-center justify-center group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">accessibility_new</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-primary font-bold truncate">
                        Obsidian Platelegs
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">+1 Str Breakpoint</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-primary text-on-primary font-bold rounded flex items-center gap-0.5 shrink-0">
                    <span className="material-symbols-outlined text-[12px]">shopping_cart</span> 980K
                  </span>
                </div>
              </div>

              {/* Row 5: Hands, Boots, Ring (3 Column row) */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-space-xs">
                {/* Hands */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-on-surface-variant group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">pan_tool</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Barrows Gloves
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Hands</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container-highest text-on-surface-variant rounded shrink-0">
                    Equipped
                  </span>
                </div>

                {/* Boots */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group bg-gradient-to-r from-primary/10 via-surface-container to-surface-container border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-primary/20 text-primary flex items-center justify-center group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">footprint</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-primary font-bold truncate">
                        Dragon Boots
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Boots</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-primary text-on-primary font-bold rounded flex items-center gap-0.5 shrink-0">
                    <span className="material-symbols-outlined text-[12px]">shopping_cart</span> 185K
                  </span>
                </div>

                {/* Ring */}
                <div className="flex items-center justify-between p-space-xs bg-surface-container rounded-lg hover:bg-surface-container-high cursor-pointer transition-colors group border border-surface-container-high/30">
                  <div className="flex items-center gap-space-xs min-w-0">
                    <div className="w-8 h-8 rounded bg-surface-container-high flex items-center justify-center text-secondary group-hover:scale-105 transition-transform">
                      <span className="material-symbols-outlined text-[18px]">emergency</span>
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="font-data-sm text-data-sm text-on-surface font-bold truncate">
                        Berserker Ring (i)
                      </span>
                      <span className="font-body-sm text-body-sm text-on-surface-variant">Ring</span>
                    </div>
                  </div>
                  <span className="font-data-sm text-data-sm px-space-xs py-0.5 bg-surface-container-highest text-on-surface-variant rounded shrink-0">
                    Equipped
                  </span>
                </div>
              </div>
            </div>

            {/* Performance Summary Deck */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-space-xs bg-surface-container p-space-md rounded-xl shadow-inner border border-surface-container-high/30">
              <div className="flex flex-col gap-0.5">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Effective DPS
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-lg text-headline-lg text-primary font-bold">6.84</span>
                  <span className="font-data-sm text-data-sm text-tertiary font-bold">+1.18</span>
                </div>
                <span className="font-data-sm text-data-sm text-tertiary">+20.8% vs base (5.66)</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">Max Hit</span>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-lg text-headline-lg text-on-surface font-bold">42</span>
                  <span className="font-data-sm text-data-sm text-tertiary font-bold">+6</span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">Baseline: 36</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">Accuracy</span>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-lg text-headline-lg text-on-surface font-bold">64.2%</span>
                  <span className="font-data-sm text-data-sm text-tertiary font-bold">+8.4%</span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">Baseline: 55.8%</span>
              </div>
              <div className="flex flex-col gap-0.5">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Attack Speed
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-lg text-headline-lg text-on-surface font-bold">4 ticks</span>
                </div>
                <span className="font-data-sm text-data-sm text-on-surface-variant">2.4s cadence</span>
              </div>
              <div className="flex flex-col gap-0.5 col-span-2 sm:col-span-1">
                <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">
                  Est. Kill Time
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="font-headline-lg text-headline-lg text-tertiary font-bold">~1m 48s</span>
                </div>
                <span className="font-data-sm text-data-sm text-tertiary font-semibold">-22s / encounter</span>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Algorithmic Rationale & Execution Actions (3 Cols) */}
        <div className="lg:col-span-3 flex flex-col gap-space-md">
          {/* Card: Why this setup? (Algorithmic Rationale) */}
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-md border border-surface-container-high/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-space-xs">
                <span className="material-symbols-outlined text-primary text-[18px]">psychology</span>
                <span className="font-headline-sm text-headline-sm text-on-surface font-bold">Why this setup?</span>
              </div>
              <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">Deterministic</span>
            </div>
            <div className="flex flex-col gap-space-sm font-body-sm text-body-sm text-on-surface">
              {/* Point 1 */}
              <div className="p-space-sm bg-surface-container rounded-lg flex flex-col gap-0.5 border border-surface-container-high/30">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps text-label-caps text-primary font-bold">
                    1. CAPITAL EFFICIENCY
                  </span>
                  <span className="font-data-sm text-data-sm text-tertiary">+0.74 DPS</span>
                </div>
                <p className="text-on-surface-variant">
                  Abyssal Whip captures <strong className="text-on-surface">62.7%</strong> of all potential damage
                  gains for only 1.65M GP.
                </p>
              </div>
              {/* Point 2 */}
              <div className="p-space-sm bg-surface-container rounded-lg flex flex-col gap-0.5 border border-surface-container-high/30">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps text-label-caps text-secondary font-bold">
                    2. MAX HIT BREAKPOINT
                  </span>
                  <span className="font-data-sm text-data-sm text-on-surface font-semibold">42 Threshold</span>
                </div>
                <p className="text-on-surface-variant">
                  Pairing Dragon Boots with Obsidian Platelegs delivers exactly{' '}
                  <strong className="text-on-surface">+3 Melee Str</strong>, crossing the damage threshold under
                  Super Strength.
                </p>
              </div>
              {/* Point 3 */}
              <div className="p-space-sm bg-surface-container rounded-lg flex flex-col gap-0.5 border border-surface-container-high/30">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps text-label-caps text-tertiary font-bold">3. VAULT RE-USE</span>
                  <span className="font-data-sm text-data-sm text-tertiary">0 GP Sunk</span>
                </div>
                <p className="text-on-surface-variant">
                  Leveraged <strong className="text-on-surface">8 owned items</strong> from bank, bypassing
                  redundant capital locks.
                </p>
              </div>
              {/* Point 4 (Rejection) */}
              <div className="p-space-sm bg-surface-container rounded-lg flex flex-col gap-0.5 border border-surface-container-high/30">
                <div className="flex items-center justify-between">
                  <span className="font-label-caps text-label-caps text-error font-bold">
                    4. CANDIDATE DISCARDED
                  </span>
                  <span className="font-data-sm text-data-sm text-error">Over Budget</span>
                </div>
                <p className="text-on-surface-variant">
                  Osmumten's Fang (7.91 DPS) rejected for exceeding 5.0M budget cap by{' '}
                  <strong className="text-error">+9.2M GP</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Action Checklist & Planner Integration */}
          <div className="bg-surface-container-low rounded-xl p-space-md shadow-md flex flex-col gap-space-sm border border-surface-container-high/30">
            <span className="font-label-caps text-label-caps text-on-surface-variant uppercase">Next Actions</span>
            <div className="flex flex-col gap-space-xs">
              {/* Checklist Item 1 */}
              <label className="flex items-center gap-space-sm p-space-sm bg-surface-container rounded hover:bg-surface-container-high cursor-pointer transition-colors border border-surface-container-high/30">
                <input
                  checked={copyCheck}
                  onChange={(e) => setCopyCheck(e.target.checked)}
                  className="w-4 h-4 rounded-sm accent-primary bg-surface-container-lowest border-0 cursor-pointer"
                  type="checkbox"
                />
                <div className="flex flex-col min-w-0">
                  <span className="font-data-sm text-data-sm text-on-surface font-semibold">
                    Copy GE Quick-Buy command
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Formatted for OSBuddy/RuneLite
                  </span>
                </div>
              </label>

              {/* Checklist Item 2 */}
              <label className="flex items-center gap-space-sm p-space-sm bg-surface-container rounded hover:bg-surface-container-high cursor-pointer transition-colors border border-surface-container-high/30">
                <input
                  checked={lockMultiStyle}
                  onChange={(e) => setLockMultiStyle(e.target.checked)}
                  className="w-4 h-4 rounded-sm accent-primary bg-surface-container-lowest border-0 cursor-pointer"
                  type="checkbox"
                />
                <div className="flex flex-col min-w-0">
                  <span className="font-data-sm text-data-sm text-on-surface font-semibold">
                    Lock setup for Multi-Style Planner
                  </span>
                  <span className="font-body-sm text-body-sm text-on-surface-variant">
                    Carry forward to 2-4 switch matrix
                  </span>
                </div>
              </label>
            </div>

            {/* MCP AI Interaction Button */}
            <button
              onClick={() => onOpenAdvisor?.('Why did the optimizer pick Abyssal Whip over Fang?')}
              className="mt-space-xs flex items-center justify-center gap-space-sm p-space-sm bg-surface-container-high hover:bg-surface-container-highest text-primary font-title-md text-title-md rounded transition-all group border border-primary/20 cursor-pointer"
              type="button"
            >
              <span className="material-symbols-outlined text-[18px] group-hover:rotate-12 transition-transform">
                smart_toy
              </span>
              <span>Discuss setup with ChatGPT</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
