/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { ScreenType, TransitionType } from './types';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { ChatGptModal } from './components/ChatGptModal';
import { SinglePreOptimization } from './screens/SinglePreOptimization';
import { SinglePostOptimization } from './screens/SinglePostOptimization';
import { SingleItemInspector } from './screens/SingleItemInspector';
import { MultiSideBySide } from './screens/MultiSideBySide';
import { MultiInteractiveSwitching } from './screens/MultiInteractiveSwitching';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('single-pre');
  const [transitionType, setTransitionType] = useState<TransitionType>('none');
  const [advisorOpen, setAdvisorOpen] = useState(false);
  const [advisorPrompt, setAdvisorPrompt] = useState<string | undefined>();

  const navigateTo = (screen: ScreenType, transition: TransitionType = 'none') => {
    setTransitionType(transition);
    setCurrentScreen(screen);
  };

  const handleOpenAdvisor = (prompt?: string) => {
    setAdvisorPrompt(prompt);
    setAdvisorOpen(true);
  };

  // Determine motion animation variants based on transition type
  const getVariants = () => {
    switch (transitionType) {
      case 'push':
        return {
          initial: { opacity: 0, x: 30 },
          animate: { opacity: 1, x: 0 },
          exit: { opacity: 0, x: -30 },
          transition: { duration: 0.2, ease: 'easeOut' as const },
        };
      case 'push_back':
        return {
          initial: { opacity: 0, x: -30 },
          animate: { opacity: 1, x: 0 },
          exit: { opacity: 0, x: 30 },
          transition: { duration: 0.2, ease: 'easeOut' as const },
        };
      case 'slide_up':
        return {
          initial: { opacity: 0, y: 40 },
          animate: { opacity: 1, y: 0 },
          exit: { opacity: 0, y: 40 },
          transition: { duration: 0.25, ease: 'easeOut' as const },
        };
      case 'none':
      default:
        return {
          initial: { opacity: 1 },
          animate: { opacity: 1 },
          exit: { opacity: 1 },
          transition: { duration: 0 },
        };
    }
  };

  const variants = getVariants();

  return (
    <div className="bg-background text-on-surface min-h-screen flex antialiased">
      {/* Fixed Left Navigation Sidebar */}
      <Sidebar currentScreen={currentScreen} onNavigate={navigateTo} />

      {/* Main Content Area (offset by sidebar w-64) */}
      <div className="pl-64 w-full flex flex-col min-h-screen">
        {/* Fixed Top Header */}
        <Header
          currentScreen={currentScreen}
          onNavigate={navigateTo}
          onOpenAdvisor={() => handleOpenAdvisor()}
        />

        {/* Dynamic Screen Content with Framer Motion transitions */}
        <main className="w-full pt-16 bg-background min-h-screen">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentScreen}
              initial={variants.initial}
              animate={variants.animate}
              exit={variants.exit}
              transition={variants.transition}
              className="w-full"
            >
              {currentScreen === 'single-pre' && (
                <SinglePreOptimization
                  onNavigate={navigateTo}
                  onOpenAdvisor={handleOpenAdvisor}
                />
              )}
              {currentScreen === 'single-post' && (
                <SinglePostOptimization
                  onNavigate={navigateTo}
                  onOpenAdvisor={handleOpenAdvisor}
                />
              )}
              {currentScreen === 'single-inspector' && (
                <SingleItemInspector
                  onNavigate={navigateTo}
                  onOpenAdvisor={handleOpenAdvisor}
                />
              )}
              {currentScreen === 'multi-side' && (
                <MultiSideBySide
                  onNavigate={navigateTo}
                  onOpenAdvisor={handleOpenAdvisor}
                />
              )}
              {currentScreen === 'multi-interactive' && (
                <MultiInteractiveSwitching
                  onNavigate={navigateTo}
                  onOpenAdvisor={handleOpenAdvisor}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* ChatGPT MCP Intelligence Modal */}
      <ChatGptModal
        isOpen={advisorOpen}
        onClose={() => setAdvisorOpen(false)}
        initialQuery={advisorPrompt}
      />
    </div>
  );
}
